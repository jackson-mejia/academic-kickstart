### Functions and libraries Script
## Note that packages were installed in R4.04. To avoid conflicts, use the groundhog
## package or ensure that dependencies are aligned with R4.04.
library(groundhog)
groundhog.library(pracma, '2021-02-15')
groundhog.library(matrixStats, '2021-02-15')
groundhog.library(dplyr, '2021-02-15')
groundhog.library(data.table, '2021-02-15')
groundhog.library(DescTools, '2021-02-15')
groundhog.library(KFAS, '2021-02-15')
groundhog.library(zoo, '2021-02-15')
groundhog.library(matrixcalc, '2021-02-15')
groundhog.library(ggplot2, '2021-02-15')
groundhog.library(optimx, '2021-02-15')
groundhog.library(reshape2, '2021-02-15')
groundhog.library(tseries, '2021-02-15')
groundhog.library(vars, '2021-02-15')
groundhog.library(MetricsWeighted, '2021-02-15')
groundhog.library(bea.R, '2021-02-15')
groundhog.library(tibble, '2021-02-15')
groundhog.library(tidyr, '2021-02-15')


# function to search BEA database to match series code with metric name, table name, etc
bea_string_search <- function(term){
  nipa_ref %>% filter(grepl(term, SeriesCode) | grepl(term, TableName) | grepl(term, LineDescription) | grepl(term, LineNumber) |
                        grepl(term, METRIC_NAME) | grepl(term, CL_UNIT) | grepl(term, UNIT_MULT))
}
#Function that returns the series code of select lines in a table at a given frequency as a character vector. Provide lines as vector
bea_table <- function(TableName, Frequency, Lines){
  if(missing(Lines)){
    paste(as.data.frame(bea_string_search(TableName))$SeriesCode, Frequency, sep = "_")
  } else{
    paste(as.data.frame(bea_string_search(TableName))$SeriesCode, Frequency, sep = "_")[Lines]
  }
}

#Hodrick-Prescott Filter that deals with missing values
HPFilter = function(x,lambda, na.omit = TRUE) {
  if(na.omit) {
    na_values = is.na(x)
    if(any(na_values)) x = x[-which(na_values)]
  }
  eye <- diag(length(x))
  result <- solve(eye+lambda*crossprod(diff(eye,lag=1,d=2)),x)
  for(idx in which(na_values)) result = append(result, NA, idx - 1) # reinsert NA values
  return(result)
}


##Supply a df with date as the first column, quarterly variables as columns 2:n-1 and column n as the annual column
## to estimate. Ensure that the series begins and ends with a non-NA annual value. Annual value should appear in
## q4 of the relevant year. For example, the annual capital stock for 2019 should be in 2019.75 (2019Q4). If detrend = TRUE, then
# only estimate the detrended series and interpolate the trend series. If flow == TRUE, then estimate a flow variable rather than a stock
kalman_out <- function(df, detrend, flow){# Function follows Ellen R. McGrattan's method from "Intangible Capital"
  if(detrend == TRUE){
    Date <- df$Date #Save Date as a vector to place next to filtered/smoothed values at the end
    Y <- unname(as.matrix(df %>% dplyr::select(-c(1)))) #remove names and Date column
    n <- ncol(Y)
    
    #initialize trend matrix
    Ytrend <- matrix(nrow = nrow(Y), ncol = ncol(Y))
    
    #Get trend component of each series after log-transforming
    for(i in 1:(n-1)){
      Ytrend[, i] <- HPFilter(Y[,i], lambda = 1600, na.omit = TRUE)
    }
    Ytrend[,n] <- HPFilter(Y[,n], lambda = 100, na.omit = TRUE)
    
    Y <- Y - Ytrend
    qY_trend <- na.approx(Ytrend) #linearly interpolate to create rough estimate for quarterly values
    
  } else{
    Date <- df$Date #Save Date as a vector to place next to filtered/smoothed values at the end
    Y <- unname(as.matrix(df %>% dplyr::select(-c(1)))) #remove names and Date column
  }
  qY <- na.approx(Y)
  
  #create matrix that places lagged values of df next to each other
  big_Y <- unname(cbind(Y, dplyr::lead(Y, n= 1L), dplyr::lead(Y, n= 2L), dplyr::lead(Y, n= 3L)))
  
  ## initialize matrices to create initial estimates following method of McGrattan
  
  n <- ncol(qY) #number of variables
  sumyx <- matrix(0L, nrow = n, ncol = 4*n+1)
  sumxx <- matrix(0L, nrow = 4*n+1, ncol = 4*n+1)
  
  for(i in 5:nrow(qY)){
    Ylag <- rbind(as.matrix(qY[i-1,]),
                  as.matrix(qY[i-2,]),
                  as.matrix(qY[i-3,]),
                  as.matrix(qY[i-4,]),
                  1
    )
    sumyx <- sumyx + as.matrix(qY[i,])%*%t(Ylag)
    sumxx <- sumxx + Ylag%*%t(Ylag)
  }
  
  A <- sumyx %*% solve(sumxx)
  Sig <- matrix(0L, nrow = n, ncol = n)
  
  for(i in 5:nrow(qY)){
    Ylag <- rbind(as.matrix(qY[i-1,]),
                  as.matrix(qY[i-2,]),
                  as.matrix(qY[i-3,]),
                  as.matrix(qY[i-4,]),
                  1
    )
    eps <- qY[i,] - A %*%Ylag
    Sig = Sig + eps %*% (t((eps)/(nrow(qY)-4)))
  }
  A <- A[,1:(4*n)]
  Sig <- t(chol(Sig))
  Theta0 <- rbind(vec(A), vec(Sig))
  
  
  Ct <- diag(4*n) #observation matrix
  A_t <- rbind(matrix(NA, nrow = n, ncol = 4*n), diag(nrow = 3*n, ncol = 4*n)) #state/transition matrix
  B <- rbind(matrix(NA, nrow = n, ncol = n))# variance/covariance matrix for observation state
  
  ss_model <- SSModel(big_Y ~ -1 + SSMcustom(Z = Ct, T = A_t, 
                                             Q = B)) #create state space model object
  
  #write function to be used as input by optim. Each value written as NA is estimated
  #given initial estimate found using method of McGrattan
  objf <- function(pars, model, estimate = TRUE) {
    vect_na <- which(is.na(model$T)) #find NA values
    
    #set initial estimates for state matrix parameters
    for(i in 1:(length(Theta0)- n^2)){
      model$T[vect_na[i]] <- pars[i]
    }
    
    #set initial estimates for state variance/covariance parameters
    for(j in (4*n*n + 1):length(Theta0)){
      model$Q[j - (4*n*n)] <- pars[j]
    }
    
    if (estimate) {
      -logLik(model)
    } else {
      model
    }
  }
  
  #find log-likelihood of parameters
  opt <- suppressWarnings(optimx(par = as.vector(Theta0), fn = objf, method = "nlminb", model = ss_model))
  
  #put optimized parameters back into SS model
  ss_model_opt <- objf(unlist(unname(c(opt[,1:length(Theta0)]))), ss_model, estimate = FALSE)
  #kalman filter/smooth SS model
  kalm <- KFS(ss_model_opt)
  
  #extract smoothed/filtered values for quarterly series from annual series
  kalm_values <- unclass(kalm$alphahat[,n])
  if(detrend == TRUE){
    kalm_values <- kalm_values + qY_trend[,n]
  }
  
  
  #write df with Dates and filtered/smoothed values
  bigg <- cbind(Date, kalm_values)
  bigg <- as.data.frame(cbind(Date, kalm_values)) 
  
  if(flow == TRUE){
    new_colnam <- paste(colnames(df)[df[,ncol(df)]], "KQ", sep = "_")
    colnames(df)[n+1] <- "kalsum"
    bigg <- bigg %>% mutate(year = substr(Date, 1, 4)) 
    df <- df %>% mutate(year = substr(Date, 1, 4)) %>% group_by(year) %>% summarise(
      sumden = mean(kalsum, na.rm = TRUE)
    ) %>% ungroup
    bigg1 <- bigg %>% group_by(year) %>% summarise(kalmsum = sum(kalm_values, na.rm = TRUE)) %>% ungroup() %>%
      left_join(df, by = c("year"))
    bigg2 <- bigg %>% left_join(bigg1, by = c("year")) %>%
      mutate(kalm_values = (kalm_values/kalmsum)*sumden) %>%
      rename(!!new_colnam := kalm_values) 
  } else{
    new_colnam <- paste(colnames(df)[df[,ncol(df)]], "KQ", sep = "_")
    bigg <- bigg %>% rename(!!new_colnam := kalm_values) %>%
      left_join(df, by = c("Date"))
  }
}

#function to extract BEA fixed asset tables
bea_extract <- function(tablename, freq, datasetname){
  #list to input into BEA API function
  FA_spec_list <- list('UserID' = '356252FE-692A-4DA7-B43F-5A36CF6CDAA6',
                       'Method' = 'GetData',
                       'datasetname' = datasetname,
                       'Frequency' = freq,
                       'TableName' = tablename,
                       'Year' = 'ALL')	
  #call BEA table API
  BDT <- as.data.frame(beaGet(FA_spec_list, asTable = TRUE, asWide = TRUE, isMeta = FALSE))
  if(is.data.frame(BDT) && nrow(BDT)==0){ #if df is empty, return df of dates
    if({{freq}} == 'A'){
      year <- (seq(1945, 2020, by = 1))
      BDT <- data.frame(year) %>% rename(date = year)
    } else if({{freq}} == 'Q'){
      year <- (seq(1945, 2020, by = .25))
      BDT <- data.frame(year) %>% rename(date = year)
    }
  } else {
    #transform date colvars from string to numeric and remove character elements
    if({{freq}} == 'A'){
      date <- as.numeric(gsub("DataValue_", "", names(dplyr::select(BDT, contains("Data")))))
      
      BDT <- BDT %>% mutate(SeriesCode = paste(TableName, LineNumber, "A", sep = "_"))
    } else if({{freq}} == 'Q'){ #if quarterly, convert Qs from 19XXQ1 to 19XX.00, etc
      date <- (gsub("DataValue_", "", names(dplyr::select(BDT, contains("Data")))))
      year <- as.numeric(substr(date, start = 1, stop = 4))
      quarter <- quarterly(date)
      date <- as.numeric(paste(year,quarter, sep = ""))
      
      BDT <- BDT %>% mutate(SeriesCode = paste(TableName, LineNumber, "Q", sep = "_"))
    }
    
    # alter SeriesCode so that each BEA table line has a unique name
    
    #initialize vector of colnames to be changed later
    deadcols <- rep(NA, length(unique(BDT$SeriesCode)))
    #create vector of colnames to be changed later (transforming to df in next line causes colnames to be called X1, X2, etc)
    for(i in 1:length(unique(BDT$SeriesCode))){
      deadcols[i] <- paste("X", i, sep = "")
    }
    #transpose BEA table after selecting only numeric variables and removing repeated rows, then rename so that BEA vars are columns
    BDT <- data.frame(t(BDT %>% dplyr::select(SeriesCode, where(is.numeric)) %>%
                          distinct())) %>% rename_at(vars(deadcols), ~ unique(BDT$SeriesCode)) %>% slice(-c(1L)) %>%
      cbind(date) %>% remove_rownames() #add in date vars
  }
}
#function for getting BEA FA metadata
bea_meta <- function(tablename, freq, datasetname){
  
  FA_spec_list <- list('UserID' = '356252FE-692A-4DA7-B43F-5A36CF6CDAA6',
                       'Method' = 'GetData',
                       'datasetname' = datasetname,
                       'Frequency' = freq,
                       'TableName' = tablename,
                       'Year' = 'ALL')	
  
  BDT <- as.data.frame(beaGet(FA_spec_list, asTable = TRUE, asWide = TRUE, isMeta = FALSE))
  #get metadata from BEA table extract
  if(is.data.frame(BDT) && nrow(BDT) != 0){
    BDT <- BDT %>% mutate(SeriesCode = paste(TableName, LineNumber, sep = "_")) %>% # alter SeriesCode so that each BEA table line has a unique name
      dplyr::select((where(is.character)))
  } else { # unless table is empty
    BDT <- data.frame(matrix(ncol=7,nrow=0, dimnames=list(NULL,c("TableName", "SeriesCode", "LineNumber", "LineDescription",
                                                                 "METRIC_NAME", "CL_UNIT", "UNIT_MULT"))))
  }
}

#convert from format 1950Q1 to 1950.00
quarterly <- function(var){
  ifelse(substr(var, start = 5, stop = 6) == "Q1", as.numeric(paste(substr(var, start = 1, stop = 4), ".00", sep = "")), 
         ifelse(substr(var, start = 5, stop = 6) == "Q2", as.numeric(paste(substr(var, start = 1, stop = 4), ".25", sep = "")), 
                ifelse(substr(var, start = 5, stop = 6) == "Q3", as.numeric(paste(substr(var, start = 1, stop = 4), ".50", sep = "")), 
                       as.numeric(paste(substr(var, start = 1, stop = 4), ".75", sep = ""))
         )
         ))
}
