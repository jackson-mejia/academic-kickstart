### Functions and libraries Script
#SET PATH HERE:
#data_dir <- 'C:/Users/Jackson_Mejia/Documents/ERM_Practice/'
data_dir <- "C:/Users/j.mejia/Downloads/macro_invt_elasticities/"

#suppress library messages
shhh <- suppressPackageStartupMessages # It's a library, so shhh!

shhh(library(pracma))
shhh(library(matrixStats))
shhh(library(dplyr))
shhh(library(data.table))
shhh(library(DescTools))
shhh(library(KFAS))
shhh(library(zoo))
shhh(library(matrixcalc))
shhh(library(ggplot2))
shhh(library(optimx))
shhh(library(reshape2))
shhh(library(tseries))
shhh(library(vars))
shhh(library(MetricsWeighted))
shhh(library(bea.R))
shhh(library(tibble))
shhh(library(plm))
shhh(library(tidyr))


# function to search BEA database to match series code with metric name, table name, etc
bea_string_search <- function(term){
  nipa_ref %>% filter(grepl(term, SeriesCode) | grepl(term, TableName) | grepl(term, LineDescription) | grepl(term, LineNumber) |
                        grepl(term, METRIC_NAME) | grepl(term, CL_UNIT) | grepl(term, UNIT_MULT))
}
#Function that returns the series code of select lines in a table at a given frequency as a character vector. Provide lines as vector
bea_table <- function(TableName, Frequency, Lines){
  if(missing(Lines)){
    paste(bea_string_search(TableName)$SeriesCode, Frequency, sep = "_")
  } else{
    paste(bea_string_search(TableName)$SeriesCode, Frequency, sep = "_")[Lines]
  }
}

#Hodrick-Prescott Filter that deals with missing values
HPFilter = function(x,lambda, na.omit = TRUE) {
  if(na.omit) {
    na_values = is.na(x)
    if(any(na_values)) x = x[-which(na_values)]
  }
  eye <- diag(length(x))
  result <- solve(eye+lambda*crossprod(diff(eye,lag=1,d=2)),x)
  for(idx in which(na_values)) result = append(result, NA, idx - 1) # reinsert NA values
  return(result)
}


##Supply a df with date as the first column, quarterly variables as columns 2:n-1 and column n as the annual column
## to estimate. Ensure that the series begins and ends with a non-NA annual value. Annual value should appear in
## q4 of the relevant year. For example, the annual capital stock for 2019 should be in 2019.75 (2019Q4). If detrend = TRUE, then
# only estimate the detrended series and interpolate the trend series. If flow == TRUE, then estimate a flow variable rather than a stock
kalman_out <- function(df, detrend, flow){# Function follows Ellen R. McGrattan's method from "Intangible Capital"
  if(detrend == TRUE){
    Date <- df$Date #Save Date as a vector to place next to filtered/smoothed values at the end
    Y <- unname(as.matrix(df %>% dplyr::select(-c(1)))) #remove names and Date column
    n <- ncol(Y)
    
    #initialize trend matrix
    Ytrend <- matrix(nrow = nrow(Y), ncol = ncol(Y))
    
    #Get trend component of each series after log-transforming
    for(i in 1:(n-1)){
      Ytrend[, i] <- HPFilter(Y[,i], lambda = 1600, na.omit = TRUE)
    }
    Ytrend[,n] <- HPFilter(Y[,n], lambda = 100, na.omit = TRUE)
    
    Y <- Y - Ytrend
    qY_trend <- na.approx(Ytrend) #linearly interpolate to create rough estimate for quarterly values
    
  } else{
    Date <- df$Date #Save Date as a vector to place next to filtered/smoothed values at the end
    Y <- unname(as.matrix(df %>% dplyr::select(-c(1)))) #remove names and Date column
  }
  qY <- na.approx(Y)
  
  #create matrix that places lagged values of df next to each other
  big_Y <- unname(cbind(Y, dplyr::lead(Y, n= 1L), dplyr::lead(Y, n= 2L), dplyr::lead(Y, n= 3L)))
  
  ## initialize matrices to create initial estimates following method of McGrattan
  
  n <- ncol(qY) #number of variables
  sumyx <- matrix(0L, nrow = n, ncol = 4*n+1)
  sumxx <- matrix(0L, nrow = 4*n+1, ncol = 4*n+1)
  
  for(i in 5:nrow(qY)){
    Ylag <- rbind(as.matrix(qY[i-1,]),
                  as.matrix(qY[i-2,]),
                  as.matrix(qY[i-3,]),
                  as.matrix(qY[i-4,]),
                  1
    )
    sumyx <- sumyx + as.matrix(qY[i,])%*%t(Ylag)
    sumxx <- sumxx + Ylag%*%t(Ylag)
  }
  
  A <- sumyx %*% solve(sumxx)
  Sig <- matrix(0L, nrow = n, ncol = n)
  
  for(i in 5:nrow(qY)){
    Ylag <- rbind(as.matrix(qY[i-1,]),
                  as.matrix(qY[i-2,]),
                  as.matrix(qY[i-3,]),
                  as.matrix(qY[i-4,]),
                  1
    )
    eps <- qY[i,] - A %*%Ylag
    Sig = Sig + eps %*% (t((eps)/(nrow(qY)-4)))
  }
  A <- A[,1:(4*n)]
  Sig <- t(chol(Sig))
  Theta0 <- rbind(vec(A), vec(Sig))
  
  
  Ct <- diag(4*n) #observation matrix
  A_t <- rbind(matrix(NA, nrow = n, ncol = 4*n), diag(nrow = 3*n, ncol = 4*n)) #state/transition matrix
  B <- rbind(matrix(NA, nrow = n, ncol = n))# variance/covariance matrix for observation state
  
  ss_model <- SSModel(big_Y ~ -1 + SSMcustom(Z = Ct, T = A_t, 
                                             Q = B)) #create state space model object
  
  #write function to be used as input by optim. Each value written as NA is estimated
  #given initial estimate found using method of McGrattan
  objf <- function(pars, model, estimate = TRUE) {
    vect_na <- which(is.na(model$T)) #find NA values
    
    #set initial estimates for state matrix parameters
    for(i in 1:(length(Theta0)- n^2)){
      model$T[vect_na[i]] <- pars[i]
    }
    
    #set initial estimates for state variance/covariance parameters
    for(j in (4*n*n + 1):length(Theta0)){
      model$Q[j - (4*n*n)] <- pars[j]
    }
    
    if (estimate) {
      -logLik(model)
    } else {
      model
    }
  }
  
  #find log-likelihood of parameters
  opt <- suppressWarnings(optimx(par = as.vector(Theta0), fn = objf, method = "nlminb", model = ss_model))
  
  #put optimized parameters back into SS model
  ss_model_opt <- objf(unlist(unname(c(opt[,1:length(Theta0)]))), ss_model, estimate = FALSE)
  #kalman filter/smooth SS model
  kalm <- KFS(ss_model_opt)
  
  #extract smoothed/filtered values for quarterly series from annual series
  kalm_values <- unclass(kalm$alphahat[,n])
  if(detrend == TRUE){
    kalm_values <- kalm_values + qY_trend[,n]
  }
  
  
  #write df with Dates and filtered/smoothed values
  bigg <- cbind(Date, kalm_values)
  bigg <- as.data.frame(cbind(Date, kalm_values)) 
  
  if(flow == TRUE){
    new_colnam <- paste(colnames(df)[df[,ncol(df)]], "KQ", sep = "_")
    colnames(df)[n+1] <- "kalsum"
    bigg <- bigg %>% mutate(year = substr(Date, 1, 4)) 
    df <- df %>% mutate(year = substr(Date, 1, 4)) %>% group_by(year) %>% summarise(
      sumden = mean(kalsum, na.rm = TRUE)
    ) %>% ungroup
    bigg1 <- bigg %>% group_by(year) %>% summarise(kalmsum = sum(kalm_values, na.rm = TRUE)) %>% ungroup() %>%
      left_join(df, by = c("year"))
    bigg2 <- bigg %>% left_join(bigg1, by = c("year")) %>%
      mutate(kalm_values = (kalm_values/kalmsum)*sumden) %>%
      rename(!!new_colnam := kalm_values) 
  } else{
    new_colnam <- paste(colnames(df)[df[,ncol(df)]], "KQ", sep = "_")
    bigg <- bigg %>% rename(!!new_colnam := kalm_values) %>%
      left_join(df, by = c("Date"))
  }
}

#function to extract BEA fixed asset tables
bea_extract <- function(tablename, freq, datasetname){
  #list to input into BEA API function
  FA_spec_list <- list('UserID' = '356252FE-692A-4DA7-B43F-5A36CF6CDAA6',
                       'Method' = 'GetData',
                       'datasetname' = datasetname,
                       'Frequency' = freq,
                       'TableName' = tablename,
                       'Year' = 'ALL')	
  #call BEA table API
  BDT <- as.data.frame(beaGet(FA_spec_list, asTable = TRUE, asWide = TRUE, isMeta = FALSE))
  if(is.data.frame(BDT) && nrow(BDT)==0){ #if df is empty, return df of dates
    if({{freq}} == 'A'){
      year <- (seq(1945, 2020, by = 1))
      BDT <- data.frame(year) %>% rename(date = year)
    } else if({{freq}} == 'Q'){
      year <- (seq(1945, 2020, by = .25))
      BDT <- data.frame(year) %>% rename(date = year)
    }
  } else {
    #transform date colvars from string to numeric and remove character elements
    if({{freq}} == 'A'){
      date <- as.numeric(gsub("DataValue_", "", names(dplyr::select(BDT, contains("Data")))))
      
      BDT <- BDT %>% mutate(SeriesCode = paste(TableName, LineNumber, "A", sep = "_"))
    } else if({{freq}} == 'Q'){ #if quarterly, convert Qs from 19XXQ1 to 19XX.00, etc
      date <- (gsub("DataValue_", "", names(dplyr::select(BDT, contains("Data")))))
      year <- as.numeric(substr(date, start = 1, stop = 4))
      quarter <- quarterly(date)
      date <- as.numeric(paste(year,quarter, sep = ""))
      
      BDT <- BDT %>% mutate(SeriesCode = paste(TableName, LineNumber, "Q", sep = "_"))
    }
    
    # alter SeriesCode so that each BEA table line has a unique name
    
    #initialize vector of colnames to be changed later
    deadcols <- rep(NA, length(unique(BDT$SeriesCode)))
    #create vector of colnames to be changed later (transforming to df in next line causes colnames to be called X1, X2, etc)
    for(i in 1:length(unique(BDT$SeriesCode))){
      deadcols[i] <- paste("X", i, sep = "")
    }
    #transpose BEA table after selecting only numeric variables and removing repeated rows, then rename so that BEA vars are columns
    BDT <- data.frame(t(BDT %>% dplyr::select(SeriesCode, where(is.numeric)) %>%
                          distinct())) %>% rename_at(vars(deadcols), ~ unique(BDT$SeriesCode)) %>% slice(-c(1L)) %>%
      cbind(date) %>% remove_rownames() #add in date vars
  }
}
#function for getting BEA FA metadata
bea_meta <- function(tablename, freq, datasetname){
  
  FA_spec_list <- list('UserID' = '356252FE-692A-4DA7-B43F-5A36CF6CDAA6',
                       'Method' = 'GetData',
                       'datasetname' = datasetname,
                       'Frequency' = freq,
                       'TableName' = tablename,
                       'Year' = 'ALL')	
  
  BDT <- as.data.frame(beaGet(FA_spec_list, asTable = TRUE, asWide = TRUE, isMeta = FALSE))
  #get metadata from BEA table extract
  if(is.data.frame(BDT) && nrow(BDT) != 0){
    BDT <- BDT %>% mutate(SeriesCode = paste(TableName, LineNumber, sep = "_")) %>% # alter SeriesCode so that each BEA table line has a unique name
      dplyr::select((where(is.character)))
  } else { # unless table is empty
    BDT <- data.frame(matrix(ncol=7,nrow=0, dimnames=list(NULL,c("TableName", "SeriesCode", "LineNumber", "LineDescription",
                                                                 "METRIC_NAME", "CL_UNIT", "UNIT_MULT"))))
  }
}


#convert from format 1950Q1 to 1950.00
quarterly <- function(var){
  ifelse(substr(var, start = 5, stop = 6) == "Q1", as.numeric(paste(substr(var, start = 1, stop = 4), ".00", sep = "")), 
         ifelse(substr(var, start = 5, stop = 6) == "Q2", as.numeric(paste(substr(var, start = 1, stop = 4), ".25", sep = "")), 
                ifelse(substr(var, start = 5, stop = 6) == "Q3", as.numeric(paste(substr(var, start = 1, stop = 4), ".50", sep = "")), 
                       as.numeric(paste(substr(var, start = 1, stop = 4), ".75", sep = ""))
         )
         ))
}

#function for setting xrd_sale to NA 
xrd_select <- function(xrdq_adj, saleq_adj, xrd_sale){
  ifelse(!is.na({{xrdq_adj}}/{{saleq_adj}}), {{xrdq_adj}}/{{saleq_adj}}, ifelse(!is.na({{xrd_sale}}), {{xrd_sale}}, NA))
}


#Filtering function
upper_lower_cut <- function(df, var, upper, lower, na.rm){
  df %>%
    filter({{var}} >= quantile({{var}}, lower, na.rm = TRUE) &
             {{var}} <= quantile({{var}}, upper, na.rm = TRUE)
           )
}


clean_naics <- function(naicsh){ #Function to Assign all subsets of NAICs codes to the parent NAICS code
  nu_naics <- ifelse(naicsh == 33 | naicsh == 32, 31,
                     ifelse(naicsh == 45, 44,
                            ifelse(naicsh == 49, 48, naicsh)))
}

#Function for when we crosswalk NAICS codes for prior to 1985. If a native code exists, use that,
# otherwise usethe code we generate
naic_all <- function(naics1, naics2){
  naics <- ifelse(!is.na(naics1), naics1, ifelse(!is.na(naics2), naics2, NA))
}

#Sets priority for which date to use for firm birth year. If Ritter date is available, use that
# otherwise first year in Compustat with final stock price, otherwise Compustat ipodate,
#otherwise first date in Compustat
clean_ipo_date <- function(ipo_1,ipodate, ipo_3){
  ipoyr <- ifelse(!is.na(ipo_1), ipo_1, 
                  ifelse(!is.na(ipodate), ipodate, 
                         ifelse(!is.na(ipo_3), ipo_3, NA)))
}

#calculate effective rate
eff_rate <- function(pi, txt){
  ifelse(pi != 0 & !is.na(pi) & !is.na(txt), txt/pi, NA)
}


#function for interpolating
interp_df <- function(df, var){
  df %>% group_by(gvkey) %>%
    arrange(fyear, .by_group = TRUE) %>%
    mutate(across(c(all_of(var)), .fns = list(interp = ~ na.approx(., maxgap = max_gap, na.rm = FALSE)))) %>%
    ungroup()
}

## Function for eliminating NAs for particular variables and specifying the minimum number of consecutive years
na_filter_a <- function(df, navars){ 
  df %>% 
    filter_at(vars(all_of(navars)),all_vars(!is.na(.))) %>%
    group_by(gvkey) %>%
    arrange(fyear, .by_group = TRUE) %>%
    #filter(n() >= n_observ) %>% 
    ungroup() %>%
    group_by(gvkey, grp = cumsum(c(1, diff(fyear) != 1))) %>% 
    filter(n() >= yrs_invest) %>% ungroup()
}

#function for adding logs and growth rates
log_growth_df <- function(df, datevar, logvars, growthvars){
  #df %>% #filter_at(logvars, all_vars(. > 0) ) %>%
    df2 <- df %>% filter_at(logvars, all_vars(. > 0 & !is.na(.)) ) %>%
      dplyr::select(c(gvkey, datevar, logvars)) %>%
    group_by(gvkey) %>%
    mutate(across(c(all_of(logvars)), list(log = ~case_when(. >= 0  & !is.na(.) ~log(.))))) %>%
    mutate(across(c(all_of(growthvars)), list(growth = ~case_when(!is.na(.) & !is.na(dplyr::lag(., n = 1L)) ~. - dplyr::lag(., n = 1L))))) %>%
    ungroup() %>%
      dplyr::select(-c(logvars))
    df <- df %>% left_join(df2, by = c("gvkey", datevar))
  # mutate_at(logvars, funs(log = log(.))) %>%
  #mutate_at(growthvars, funs(growth = . - dplyr::lag(., n = 1L))) %>% ungroup()
}

## Function for eliminating NAs for particular variables and specifying the minimum number of consecutive years (for quarterly series)
 na_filter_q <- function(df, navars){ 
   df %>% 
     filter_at(vars(all_of(navars)),all_vars(!is.na(.))) %>%
     group_by(gvkey) %>%
     arrange(date, .by_group = TRUE) %>%
     #filter(n() >= n_observ) %>% 
     ungroup() %>%
     group_by(gvkey, grp = cumsum(c(1, diff(date) != .25))) %>% 
     filter(n() >= yrs_invest) %>% ungroup()
 }


#function convert to Q1, Q2, etc
convert_quarterly <- function(var){
  ifelse(substr(var, start = 5, stop = 7) == ".25", "Q2", 
         ifelse(substr(var, start = 5, stop = 7) == ".5", "Q3", ifelse(
           substr(var, start = 5, stop = 7) == ".75", "Q4", "Q1"
         )
         ))
}

#function for interpreting ytd variables as quarterly
ytd <- function(df, var_l){
  df %>% group_by(tic, fyearq) %>%
    mutate(across(c(all_of(var_l)), .fns = list(q = ~. - dplyr::lag(., n = 1L, default = 0)))) %>% ungroup()
  # mutate_at(var_l, funs(q = . - dplyr::lag(., n = 1L, default = 0)))
}

# plotting function for comparing compustat and bea investment rates
invt_plot <- function(df, comp_rate, bea_rate, rate_type){
  ggplot(df, aes(x = Date)) +
    geom_line(aes(y = {{comp_rate}}, colour = "Compustat Investment Rate"), size = 1.25) +
    geom_line(aes(y = {{bea_rate}}*1, colour = "Aggregate Investment Rate"), size = 1.25) +
    #scale_y_continuous(sec.axis = sec_axis(~./1, name = "Aggregate Investment Rate")) +
    #scale_colour_manual(values = c("blue", "red")) +
    labs(y = ifelse(rate_type == "Net", "Net Investment Rate", "Gross Investment Rate"),
         x = "Year",
         colour = "Parameter") + 
    theme_minimal() +
    theme(legend.position = "bottom") +
    theme(axis.title.y = element_text(margin = margin(t = 0, r = 10, b = 0, l = 0))) +
    theme(axis.title.y.right = element_text(margin = margin(t = 0, r = 0, b = 0, l = 10))) + 
    theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
    theme(panel.border = element_blank(), axis.line = element_line()) + 
    theme(legend.title = element_blank())
}



#Function for running VAR and extracting IRF. Takes a TS with variables and a string for the response variable in IRF
run_var_irf <- function(v, invt, nahead){
  Model1 <- VAR(v, p = 12, type = "const", season = NULL, exog = NULL)   #VAR of 12 lags
  # IRF with a tax impulse
  irf <- irf(Model1, impulse = "TAX", response = invt, ortho = FALSE, cumulative = FALSE,  n.ahead = nahead, boot = TRUE, runs = 200, ci = 0.68)
}

# Function for converting IRF from list to DF so that it plays nice with ggplot2. takes irf, string of impulse being used, and string of frequency ("A" or "Q")
extract_varirf <- function(irf, tax, freq){
  period <- seq(0, nrow(irf$irf[[1]]) - 1)
  col2 <- c(irf$irf[[1]])
  col3 <- c(irf$Lower[[1]])
  col4 <- c(irf$Upper[[1]])
  shock_var <- rep(tax, nrow(irf$irf[[1]]))
  frequency <- rep(freq, nrow(irf$irf[[1]]))
  deadcols <- c("col2", "col3", "col4")
  new_names <- c(paste("irf", irf$response, sep = "_"), paste("irf", irf$response, "lower", sep = "_"),
                 paste("irf", irf$response, "upper", sep = "_"))
  df <- data.frame(period, col2, col3, col4, shock_var, frequency) %>% rename_at(vars(deadcols), ~ (new_names))
}

#function to plot IRF as ggplot in for loop below. Takes impulse response function object which contains periods, central measure, and error bounds as well as the impulse response variable as string
plot_irf <- function(irf, invt, tax){
  cname <- names(irf) 
  cname[2] <- "irf_central" 
  cname[3] <- "irf_lower"
  cname[4] <- "irf_upper"
  colnames(irf) <- cname #rename to have general column names for aesthetics below
  irf %>% 
    ggplot(aes(x=period, y=irf_central, ymin=irf_lower, ymax=irf_upper)) +
    geom_hline(yintercept = 0, color="red") +
    geom_ribbon(fill="grey", alpha=0.2) +
    geom_line(size = 1.1) +
    theme_light() +
    ggtitle(paste(tax, invt, sep = " shock to "))+ #make impulse response variable as title
    ylab("Percent")+
    xlab("Periods Ahead") +
    theme(plot.title = element_text(size = 11, hjust=0.5),
          axis.title.y = element_text(size=11)) + theme_minimal()
}


#function that takes impulse response function df and outputs the peak (minimum) value and period in which it occurs
peak_finder <- function(irf){
  cname <- names(irf)
  cname[2] <- "irf_central" 
  colnames(irf) <- cname # rename central tendency in IRF to have a general name to make coding easier in a for loop
  irf <- irf %>% dplyr::select(-matches("lower"), -matches("upper")) %>% # remove extraneous columns
    group_by(irf_central) %>% slice_min(irf_central) %>% ungroup() %>% slice_head(n = 1) #get min value by central IRF tendency and keep only the row with min value and period
}


#Function to create two- or three-variable timeseries df with tax ordered first, then log GDP (if GDP == TRUE), then the log of investment var (unless investment is a rate)
var_ts <- function(invt, tax, method, freq, GDP, trans_negs, df){ # Method == 1 indicates investment should be logged, freq == 1 indicates annual series
  if(freq == 1){
    if(method == 1){
      invt_var <- romerdata_a %>% dplyr::select(one_of(invt))
      invt_var[invt_var == 0] <- NA
      invt_var <- 100*log(invt_var) #for level variables--take log to get response in percent
      ts_invt <- ts(invt_var, start = c(romerdata_a$Date[1]), frequency = freq) #create TS to start at first non-NA value
    } else if (method == 0) {
      invt_var <- romerdata_a %>%  dplyr::select(one_of(invt))
      ts_invt <- ts(invt_var, start = c(romerdata_a$Date[1]), frequency = freq) #create TS to start at first non-NA value
    }
    tax1 <-  romerdata_a %>% dplyr::select(c(tax))
    TAX <- ts(tax1, start = c(romerdata_a$Date[1]), frequency = 1) #create TS with start date as first non-NA value
    if(invt != "RA_T10103_1" & GDP == TRUE){
      gdpt <- 100*log(romerdata_a %>% dplyr::select(c(RA_T10103_1)))
      GDP <- ts(gdpt, start = c(romerdata_a$Date[1]), frequency = 1 )
      v1 <- na.omit(cbind(TAX,ts_invt, GDP))
    } else{
      v1 <- na.omit(cbind(TAX, ts_invt))
    }
  }else{
    if(method == 1){
      invt_var <- df %>% dplyr::select(one_of(invt))
      if(trans_negs == TRUE & any(invt_var < 0, na.rm = T)){
        min_val <- invt_var %>% summarise(min_val = min(., na.rm = TRUE))
        invt_var <- invt_var + abs(min_val[1,]) + 1
      } else{
        invt_var <- invt_var
      }
      invt_var[invt_var == 0] <- NA
      invt_var <- 100*log(invt_var) #for level variables--take log to get response in percent
      ts_invt <- ts(invt_var, start = c(df$Date[1]), frequency = 4) #create TS to start at first non-NA value
    } else if (method == 0) {
      invt_var <- df %>%  dplyr::select(one_of(invt))
      ts_invt <- ts(invt_var, start = c(df$Date[1]), frequency = 4) #create TS to start at first non-NA value
    }
    tax1 <-  df %>% dplyr::select(c(tax))
    TAX <- ts(tax1, start = c(df$Date[1]), frequency = 4) #create TS with start date as first non-NA value
    if(invt != "GDP" & GDP == TRUE){
      gdpt <- 100*log(df %>% dplyr::select(c(GDP)))
      GDP <- ts(gdpt, start = c(df$Date[1]), frequency = 4 )
      v1 <- na.omit(cbind(TAX, GDP, ts_invt))
    } else{
      v1 <- na.omit(cbind(TAX, ts_invt))
    }
  }
  #colnames(v1)[colnames(romerda) == "ts_invt"] <- invt
}



# create time series for impulse response variables (levels). takes df that contains variables and the variable in question as string. Also takes method as numeric (1 or 0) corresponding to log or level transformation and frequency as numeric (4 = Q, 1 = A)
invt_ts <- function(df, invt, tax, method, freq){
  df <- df %>% filter(!is.na(!!sym(invt)) & !is.na(!!sym(tax))) #remove NA values so that start date is correct
  if(method == 1){ #take log if method is 1 otherwise leave alone
    invt_var <- 100*log(df %>% dplyr::select(one_of(invt))) #for level variables--take log to get response in percent
    invt_var[invt_var == -Inf] <- 0
    
  } else if (method == 0) {
    invt_var <- df %>%  
      dplyr::select(one_of(invt))
  }
  ts_invt <- ts(invt_var, start = c(df$Date[1]), frequency = freq) #create TS to start at first non-NA value
}

# create time series for tax vars. Takes df and IRF var and tax var as strings. Also takes method as numeric (1 or 0) corresponding to log or level transformation and frequency as numeric (4 = Q, 1 = A)
tax_ts <- function(df, invt, tax, freq){
  df <- df %>% filter(!is.na(!!sym(invt)) & !is.na(!!sym(tax))) # have to convert string to symbol to evaluate. Remove NA values so that VAR works
  tax1 <-  df %>% dplyr::select(c(tax))
  TAXts <- ts(tax1, start = c(df$Date[1]), frequency = freq) #create TS with start date as first non-NA value
}

## Computes KZ and HP indices for annual frequency (both) and quarterly frequency (HP)
constrained_index <- function(df, frequency){
  if(frequency == "A"){
    df <- df %>% mutate(kz_index = -1.001909*(ib+dp)/dplyr::lag(ppent, n = 1L) + 0.2826389*(at + prcc_f*csho -ceq -txdb)/at + 3.139193*((dltt + dlc)/(dltt + dlc + seq)) - 39.3678*((dvc + dvp)/dplyr::lag(ppent, n = 1L)) - 1.314759*(che/dplyr::lag(ppent, n = 1L)),
                      hp_index = -0.737*log(ifelse(at < 4500, at, 4500)) + 0.043*(log(ifelse(at < 4500, at, 4500)))^2 - 0.040*ifelse(age < 37, age, 37),
                      kz_index = ifelse(is.infinite(kz_index), NA, kz_index))
    df2 <- df %>% group_by(fyear) %>% summarise(kz_threshold = quantile(kz_index, .66, na.rm = TRUE),
                                              hp_threshold = quantile(hp_index, .66, na.rm = TRUE))
    df <- df %>% left_join(df2, by = c("fyear")) %>%
    mutate(kz_con = ifelse(dplyr::lag(kz_index, n = 1L) > dplyr::lag(kz_threshold, n = 1L), 1, 0),
           hp_con = ifelse(dplyr::lag(hp_index, n = 1L) > dplyr::lag(hp_threshold, n = 1L), 1, 0))
  } else{
    df <- df %>% mutate(hp_index = -0.737*log(ifelse(atq_adj_interp < 4500, atq_adj_interp, 4500)) + 0.043*(log(ifelse(atq_adj_interp < 4500, atq_adj_interp, 4500)))^2 - 0.040*ifelse(age < 37, age, 37))
    
    df2 <- df %>% dplyr::select(c(kz_index, fyearq)) %>% group_by(fyearq) %>% summarise(kz_threshold = quantile(kz_index, .66, na.rm = TRUE)) %>% ungroup()
    df3 <- df %>% dplyr::select(c(hp_index, date)) %>% group_by(date) %>% summarise(hp_threshold = quantile(hp_index, .66, na.rm = TRUE)) %>% ungroup()
    df <- df %>% dplyr::select(-c(kz_threshold)) %>% left_join(df2, by = c("fyearq")) %>% left_join(df3, by = c("date")) %>%
      mutate(hp_con = ifelse(dplyr::lag(hp_index, n = 1L) > dplyr::lag(hp_threshold, n = 1L), 1, 0)) %>% group_by(gvkey, fyearq) %>%
      mutate(kz_con = ifelse(dplyr::lag(kz_index, n = 1L) > dplyr::lag(kz_threshold, n = 1L), 1, 0)) %>% ungroup()
    }
  
  
}

# Function to categorize firm as high roa or not (1 or 0) based on prior period threshold
high_roa <- function(df, roa, datevar, threshold){
  df2 <- df %>% group_by({{datevar}}) %>% summarise(roa_thresh = quantile(roa, threshold, na.rm = TRUE))
  df <- df %>% left_join(df2) %>% mutate(high_roa = ifelse(roa > dplyr::lag(roa_thresh, n = 1L), 1, 0))
}

## Function to plot multiple IRFs on top of each other. If Conf_Int == TRUE, then confidence bands are also plotted
multi_irf_plots <- function(plot_vars, Conf_Int, Title, irf_plots, invt_vars_exp){ # takes a vector of strings where each string corresponds to a dependent variable appended with the index of the desired tax variable. Eg, if we want fixed investment with T_CI and T_CI is the second tax variable, then it would be FI_2
  irfdata <- data.frame(matrix(ncol = 5, nrow = 0, dimnames = list(NULL, c("time", "y", "ymin", "ymax", "group"))))
  for(i in 1:length(plot_vars)){ 
    # test if data is annual. if it is, linearly interpolate so that it is on the same scale
    if( length(ggplot_build(irf_plots[[match(plot_vars[i], invt_vars_exp)]])$data[[3]]$y) < 20 ){
      time2 <- data.frame(seq(0,20,1))
      colnames(time2) <- "time"
      time <- seq(0,20,4)
      y <- ggplot_build(irf_plots[[match(plot_vars[i], invt_vars_exp)]])$data[[3]]$y
      ymin <- ggplot_build(irf_plots[[match(plot_vars[i], invt_vars_exp)]])$data[[3]]$ymin
      ymax <- ggplot_build(irf_plots[[match(plot_vars[i], invt_vars_exp)]])$data[[3]]$ymax
      time2 <- time2 %>% left_join(data.frame(time, y, ymin, ymax)) %>%
        mutate(y = na.approx(y),
               ymin = na.approx(ymin),
               ymax = na.approx(ymax),
               variable = paste(plot_vars[i]))
      irfdata <- irfdata %>% rbind(time2)
    } else {
      irftime <- seq(0,20,1)
      y <- ggplot_build(irf_plots[[match(plot_vars[i], invt_vars_exp)]])$data[[3]]$y
      ymin <- ggplot_build(irf_plots[[match(plot_vars[i], invt_vars_exp)]])$data[[3]]$ymin
      ymax <- ggplot_build(irf_plots[[match(plot_vars[i], invt_vars_exp)]])$data[[3]]$ymax
      irft <- data.frame(irftime, y, ymin, ymax)
      irft <- irft %>% rename(time = irftime) %>% mutate(variable = paste(plot_vars[i]))
      irfdata <- irfdata %>% rbind(irft)
    }
  }
  if(Conf_Int == TRUE){
  irfdata %>% ggplot(aes(time, y, fill = variable, colour = variable)) + 
    geom_ribbon(aes(ymin = ymin, ymax = ymax, group = variable),
                alpha = 0.2, linetype = 0) + geom_line(size = 1.1) + 
    geom_hline(yintercept = 0, color="black", size = 1.25) + ylab("Percent") + theme_minimal() +
    theme(legend.position="bottom") + theme(panel.grid.major = element_blank()) + ggtitle(Title)
  } else{
    irfdata %>% ggplot(aes(time, y, fill = variable, colour = variable)) + 
      geom_line(size = 1.1) + 
      geom_hline(yintercept = 0, color="black", size = 1.25) + ylab("Percent") + theme_minimal() +
      theme(legend.position="bottom") + theme(panel.grid.major = element_blank() ) + ggtitle(Title)
  }
}

## FUnction for plotting two jorda IRFs on top of each other. Takes an lpirfs object with firm controls and one without
jordadf <- function(jorda1, jorda2, period_ahead, Title, flip){
  quarters <- seq(from = 0,to = period_ahead, by = 1)
  if(flip == TRUE){
    y <- -1*c(0, as.vector(jorda1[[1]]))
    ymin <- -1*c(0, as.vector(jorda1[[2]]))
    ymax <- -1*c(0, as.vector(jorda1[[3]]))
    variable = rep("No Controls", period_ahead + 1)
    df1 <- data.frame(quarters, y, ymin, ymax, variable)
    
    quarters <- seq(from = 0,to = period_ahead, by = 1)
    y <- -1*c(0, as.vector(jorda2[[1]]))
    ymin <- -1*c(0, as.vector(jorda2[[2]]))
    ymax <- -1*c(0, as.vector(jorda2[[3]]))
    variable = rep("Firm Controls", period_ahead + 1)
    df2 <- data.frame(quarters, y, ymin, ymax, variable)
    df <- rbind(df1, df2)
  } else{
  y <- c(0, as.vector(jorda1[[1]]))
  ymin <- c(0, as.vector(jorda1[[2]]))
  ymax <- c(0, as.vector(jorda1[[3]]))
  variable = rep("No Controls", period_ahead + 1)
  df1 <- data.frame(quarters, y, ymin, ymax, variable)
  
  quarters <- seq(from = 0,to = period_ahead, by = 1)
  y <- c(0, as.vector(jorda2[[1]]))
  ymin <- c(0, as.vector(jorda2[[2]]))
  ymax <- c(0, as.vector(jorda2[[3]]))
  variable = rep("Firm Controls", period_ahead + 1)
  df2 <- data.frame(quarters, y, ymin, ymax, variable)
  df <- rbind(df1, df2)
  }
  df %>% ggplot(aes(x = quarters, y, fill = variable, colour = variable)) + 
    geom_ribbon(aes(ymin = ymin, ymax = ymax, group = variable),
                alpha = 0.2, linetype = 0) + geom_line(size = 1.1) + 
    geom_hline(yintercept = 0, color="black", size = 1.25) + ylab("Percent") + theme_minimal() +
    theme(legend.position="bottom") + 
    theme(legend.title = element_blank()) + ggtitle(Title) +  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
    theme(panel.border = element_blank(), axis.line = element_line()) + xlab("Quarters Ahead")
}

jorda_split <- function(jorda1, jorda2, period_ahead, Title){
  quarters <- seq(from = 0,to = period_ahead, by = 1)
    y <- c(0, as.vector(jorda1[[1]]))
    ymin <- c(0, as.vector(jorda1[[2]]))
    ymax <- c(0, as.vector(jorda1[[3]]))
    variable = rep("Positive Shock", period_ahead + 1)
    df1 <- data.frame(quarters, y, ymin, ymax, variable)
    
    quarters <- seq(from = 0,to = period_ahead, by = 1)
    y <- -1*c(0, as.vector(jorda2[[1]]))
    ymin <- -1*c(0, as.vector(jorda2[[2]]))
    ymax <- -1*c(0, as.vector(jorda2[[3]]))
    variable = rep("Negative Shock", period_ahead + 1)
    df2 <- data.frame(quarters, y, ymin, ymax, variable)
    df <- rbind(df1, df2)

  df %>% ggplot(aes(x = quarters, y, fill = variable, colour = variable)) + 
    geom_ribbon(aes(ymin = ymin, ymax = ymax, group = variable),
                alpha = 0.2, linetype = 0) + geom_line(size = 1.1) + 
    geom_hline(yintercept = 0, color="black", size = 1.25) + ylab("Percent") + theme_minimal() +
    theme(legend.position="bottom") + 
    theme(legend.title = element_blank()) + ggtitle(Title) +  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
    theme(panel.border = element_blank(), axis.line = element_line()) + xlab("Quarters Ahead")
}

fig1rr <- function(variable){
  #Set vector of variables we want for impulse response functions
  invt_vars <-  c("T50303_3_Q", "T50303_9_Q", "T50303_16_Q")
  #initialize list to contain IRF plots
  irf_plots <- list()
  tax_shocks <- c("EXOGENRRATIO")
  # initialize NA vector to put peak (minimum) values in
  peak_v <- rep(NA, length(invt_vars)*length(tax_shocks))
  #initialize NA vector to put peak period in
  quarters_v <- rep(NA, length(invt_vars)*length(tax_shocks))
  dep_vars <-rep(invt_vars, length(tax_shocks))
  #initialize df to contain a column of IRF vars, the period in which the peak occurred, and the peak value
  peak_df <- data.frame(dep_vars, quarters_v, peak_v)
  
  # initialize vector to contain i*j names of impulse responses, with each name taking the form i_j, i \in {invt_vars}, j \in {tax_shocks}
  invt_vars_exp <- rep(NA, nrow(peak_df))
  #loop over IRF vars to create TS object, run VAR, get IRF, extract min value, and plot IRF
  for(j in 1:length(tax_shocks)){
    for(i in 1:length(invt_vars)){
      if(invt_vars[i] %in% names(romerdata_q)){
        if(grepl("rate", invt_vars[i])){
          v1 <- var_ts(invt_vars[i], tax_shocks[j], 0, 4, GDP = FALSE) # create time series for IRF response var
        } else {
          v1 <- var_ts(invt_vars[i], tax_shocks[j], 1, 4, GDP = TRUE, trans_negs = TRUE, romerdata_q) 
        }
        
        colnames(v1)[colnames(v1) == "ts_invt"] <- invt_vars[i] # rename TS column names
        
        irf <- run_var_irf(v1, invt_vars[i], 20) # run VAR and get IRF
        irf <- extract_varirf(irf, tax_shocks[j], "Q") # get IRF in readable format
        plot <- plot_irf(irf, invt_vars[i], tax_shocks[j]) # plot IRF
        
        peak_df[(j-1)*length(invt_vars) + i,2:5] <- peak_finder(irf) # extract min value and period
        
        irf_plots[[(j-1)*length(invt_vars) + i]] <- plot # save plot
        invt_vars_exp[(j-1)*length(invt_vars) + i] <- paste(invt_vars[i], j, sep=  "_")
        
      } 
      else{
        if(grepl("rate", invt_vars[i])){
          v1 <- var_ts(invt_vars[i], tax_shocks[j], 0, 1, GDP = FALSE) # create time series for IRF response var
        } else {
          v1 <- var_ts(invt_vars[i], tax_shocks[j], 1, 1, GDP = FALSE) 
        }
        
        colnames(v1)[colnames(v1) == "ts_invt"] <- invt_vars[i] # rename TS column names
        
        irf <- run_var_irf(v1, invt_vars[i], 5) # run VAR and get IRF
        irf <- extract_varirf(irf, tax_shocks[j], "A") # get IRF in readable format
        plot <- plot_irf(irf, invt_vars[i], tax_shocks[j]) # plot IRF
        
        peak_df[(j-1)*length(invt_vars) + i,2:5] <- peak_finder(irf) # extract min value and period
        
        irf_plots[[(j-1)*length(invt_vars)+ i]] <- plot # save plot
        invt_vars_exp[(j-1)*length(invt_vars) + i] <- paste(invt_vars[i], j, sep = "_")
      }
    }
  }
  if(variable == "structures"){
    irf_plots[[1]] + ggtitle("Structures") + theme(legend.position="bottom") + theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
      theme(panel.border = element_blank(), axis.line = element_line()) + xlab("Quarters Ahead")
  } else if(variable == "equipment"){
    irf_plots[[2]] + ggtitle("Equipment") + theme(legend.position="bottom") + theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
      theme(panel.border = element_blank(), axis.line = element_line()) + xlab("Quarters Ahead")
  } else if(variable == "ip"){
    irf_plots[[3]] + ggtitle("Intellectual Property") + theme(legend.position="bottom") + theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
      theme(panel.border = element_blank(), axis.line = element_line()) + xlab("Quarters Ahead")
  }
}

hetero_rr <- function(variable){
  tax_shocks <- c("EXOGENRRATIO")
  #Set vector of variables we want for impulse response functions
  if(variable == "all"){
    invt_vars <- c(romer_extend_vars)
  } else if(variable == "major_type"){
    invt_vars <- c("T50303_2_Q", "T50303_20_Q")
  } else if(variable == "nonresidential"){
    invt_vars <- c("T50303_3_Q", "T50303_9_Q", "T50303_16_Q")
  } else if(variable == "structures"){
    invt_vars <- c("T50303_4_Q", "T50303_5_Q", "T50303_6_Q", "T50303_7_Q", "T50303_8_Q")
  } else if(variable == "equipment"){
    invt_vars <- c("T50303_10_Q", "T50303_13_Q", "T50303_14_Q", "T50303_15_Q")
  } else if(variable == "ip"){
    invt_vars <- c("T50303_17_Q", "T50303_18_Q", "T50303_19_Q")
  } else if(variable == "gfcf_ci"){
    invt_vars <- c("fof_gfcf", "fof_nc_nonres_gfcf")
    tax_shocks <- c("T_CI")
    romerdata_q <- romerdata_q %>% filter(Date >= 1951.75)
  } else if(variable == "gfcf_pi"){
    invt_vars <- c("fof_gfcf", "fof_nc_nonres_gfcf")
    tax_shocks <- c("T_PI")
    romerdata_q <- romerdata_q %>% filter(Date >= 1951.75)
  } else if(variable == "fof_tot_ci"){
    invt_vars <- c("fof_nc_net_all_cc", "fof_net_all_cc")
    tax_shocks <- c("T_CI")
    romerdata_q <- romerdata_q %>% filter(Date >= 1952)
  } else if(variable == "fof_tot_pi"){
    invt_vars <- c("fof_nc_net_all_cc", "fof_net_all_cc")
    tax_shocks <- c("T_PI")
    romerdata_q <- romerdata_q %>% filter(Date >= 1952)
  } else if(variable == "fof_struct_ci"){
    invt_vars <- c("fof_net_struct_cc", "fof_nc_net_struct_cc")
    tax_shocks <- c("T_CI")
    romerdata_q <- romerdata_q %>% filter(Date >= 1951.75)
  } else if(variable == "fof_struct_pi"){
    invt_vars <- c("fof_net_struct_cc", "fof_nc_net_struct_cc")
    tax_shocks <- c("T_PI")
    romerdata_q <- romerdata_q %>% filter(Date >= 1951.75)
  } else if(variable == "fof_equip_ci"){
    invt_vars <- c("fof_net_equip_cc", "fof_nc_net_equip_cc")
    tax_shocks <- c("T_CI")
    romerdata_q <- romerdata_q %>% filter(Date >= 1951.75)
  } else if(variable == "fof_equip_pi"){
    invt_vars <- c("fof_net_equip_cc", "fof_nc_net_equip_cc")
    tax_shocks <- c("T_PI")
    romerdata_q <- romerdata_q %>% filter(Date >= 1951.75)
  } else if(variable == "fof_intan_ci"){
    invt_vars <- c("fof_net_intan_cc", "fof_nc_net_ip_cc")
    tax_shocks <- c("T_CI")
    romerdata_q <- romerdata_q %>% filter(Date >= 1952)
  } else if(variable == "fof_intan_pi"){
    invt_vars <- c("fof_net_intan_cc", "fof_nc_net_ip_cc")
    tax_shocks <- c("T_PI")
    romerdata_q <- romerdata_q %>% filter(Date >= 1952)
  } else if(variable == "faat_tot_ci"){
    invt_vars <- c("FAAt407_37_A_KQ", "FAAt407_41_A_KQ")
    tax_shocks <- c("T_CI")
  } else if(variable == "faat_tot_pi"){
    invt_vars <- c("FAAt407_37_A_KQ", "FAAt407_41_A_KQ")
    tax_shocks <- c("T_PI")
  } else if(variable == "faat_equip_ci"){
    invt_vars <- c("FAAt407_38_A_KQ", "FAAt407_42_A_KQ")
    tax_shocks <- c("T_CI")
  } else if(variable == "faat_equip_pi"){
    invt_vars <- c("FAAt407_38_A_KQ", "FAAt407_42_A_KQ")
    tax_shocks <- c("T_PI")
  } else if(variable == "faat_struct_ci"){
    invt_vars <- c("FAAt407_39_A_KQ", "FAAt407_43_A_KQ")
    tax_shocks <- c("T_CI")
  } else if(variable == "faat_struct_pi"){
    invt_vars <- c("FAAt407_39_A_KQ", "FAAt407_43_A_KQ")
    tax_shocks <- c("T_PI")
  } else if(variable == "faat_intan_ci"){
    invt_vars <- c("FAAt407_40_A_KQ", "FAAt407_44_A_KQ")
    tax_shocks <- c("T_CI")
  } else if(variable == "faat_intan_pi"){
    invt_vars <- c("FAAt407_40_A_KQ", "FAAt407_44_A_KQ")
    tax_shocks <- c("T_PI")
  } else if(variable == "gdp_split"){
    invt_vars <- "GDP"
    tax_shocks <- c("EXOGENRRATIO_POS", "EXOGENRRATIO_NEG")
    romerdata_q <- romerdata_q %>% filter(Date >= 1975)
  } else if(variable == "gpdi_split"){
    invt_vars <- "GPDI"
    tax_shocks <- c("EXOGENRRATIO_POS", "EXOGENRRATIO_NEG")
    romerdata_q <- romerdata_q %>% filter(Date >= 1975)
  } else if(variable == "fi_split"){
    invt_vars <- "FI"
    tax_shocks <- c("EXOGENRRATIO_POS", "EXOGENRRATIO_NEG")
    romerdata_q <- romerdata_q %>% filter(Date >= 1975)
  } else if(variable == "nonres_split"){
    invt_vars <- "NONRES"
    tax_shocks <- c("EXOGENRRATIO_POS", "EXOGENRRATIO_NEG")
    romerdata_q <- romerdata_q %>% filter(Date >= 1975)
  } else if(variable == "res_split"){
    invt_vars <- "RES"
    tax_shocks <- c("EXOGENRRATIO_POS", "EXOGENRRATIO_NEG")
    romerdata_q <- romerdata_q %>% filter(Date >= 1975)
  }
  #initialize list to contain IRF plots
  irf_plots <- list()
  # initialize NA vector to put peak (minimum) values in
  peak_v <- rep(NA, length(invt_vars)*length(tax_shocks))
  #initialize NA vector to put peak period in
  quarters_v <- rep(NA, length(invt_vars)*length(tax_shocks))
  dep_vars <-rep(invt_vars, length(tax_shocks))
  #initialize df to contain a column of IRF vars, the period in which the peak occurred, and the peak value
  peak_df <- data.frame(dep_vars, quarters_v, peak_v)
  
  # initialize vector to contain i*j names of impulse responses, with each name taking the form i_j, i \in {invt_vars}, j \in {tax_shocks}
  invt_vars_exp <- rep(NA, nrow(peak_df))
  #loop over IRF vars to create TS object, run VAR, get IRF, extract min value, and plot IRF
  for(j in 1:length(tax_shocks)){
    for(i in 1:length(invt_vars)){
      
        v1 <- var_ts(invt_vars[i], tax_shocks[j], 1, 4, GDP = TRUE, trans_negs = TRUE, romerdata_q) 
        
        colnames(v1)[colnames(v1) == "ts_invt"] <- invt_vars[i] # rename TS column names
        
        irf <- run_var_irf(v1, invt_vars[i], 20) # run VAR and get IRF
        irf <- extract_varirf(irf, tax_shocks[j], "Q") # get IRF in readable format
        plot <- plot_irf(irf, invt_vars[i], tax_shocks[j]) # plot IRF
        
        peak_df[(j-1)*length(invt_vars) + i,2:5] <- peak_finder(irf) # extract min value and period
        
        irf_plots[[(j-1)*length(invt_vars) + i]] <- plot # save plot
        invt_vars_exp[(j-1)*length(invt_vars) + i] <- paste(invt_vars[i], j, sep=  "_")
      } 
    }
  if(variable == "all"){
    multi_irf_plots(all_of(invt_vars_exp), Conf_Int = FALSE, Title = "", irf_plots = irf_plots, invt_vars_exp = invt_vars_exp) + 
      theme(legend.position="none")+ theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
      theme(panel.border = element_blank(), axis.line = element_line()) + xlab("Quarters Ahead")
  } else if(variable == "major_type"){
    multi_irf_plots(c("T50303_2_Q_1", "T50303_20_Q_1"), Conf_Int = TRUE, Title = "By Major Type", irf_plots = irf_plots, invt_vars_exp = invt_vars_exp) + theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
      theme(panel.border = element_blank(), axis.line = element_line()) + xlab("Quarters Ahead") + theme(legend.title = element_blank()) +
      scale_color_hue(labels = c("Nonresidential", "Residential")) + guides(fill = FALSE)
  } else if(variable == "nonresidential"){
    multi_irf_plots(c("T50303_3_Q_1", "T50303_9_Q_1", "T50303_16_Q_1"), Conf_Int = TRUE, Title = "By Nonresidential Type", irf_plots = irf_plots, invt_vars_exp = invt_vars_exp) + theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
      theme(panel.border = element_blank(), axis.line = element_line()) + xlab("Quarters Ahead") + theme(legend.title = element_blank()) +
      scale_color_hue(labels = c("Intellectual Property", "Structures", "Equipment")) + guides(fill = FALSE)
  } else if(variable == "structures"){
    multi_irf_plots(c("T50303_4_Q_1", "T50303_5_Q_1", "T50303_6_Q_1", "T50303_7_Q_1", "T50303_8_Q_1"), Conf_Int = TRUE, Title = "By Structures Type", irf_plots = irf_plots, invt_vars_exp = invt_vars_exp) + theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
      theme(panel.border = element_blank(), axis.line = element_line()) + xlab("Quarters Ahead") + theme(legend.title = element_blank())  +
      scale_color_hue(labels = c("Commercial", "Manufacturing", "Power", "Mining", "Other")) + guides(fill = FALSE)
  } else if(variable == "equipment"){
    multi_irf_plots(c("T50303_10_Q_1", "T50303_13_Q_1", "T50303_14_Q_1", "T50303_15_Q_1"), Conf_Int = TRUE, Title = "By Equipment Type", irf_plots = irf_plots, invt_vars_exp = invt_vars_exp) + theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
      theme(panel.border = element_blank(), axis.line = element_line()) + xlab("Quarters Ahead") + theme(legend.title = element_blank())  +
      scale_color_hue(labels = c("Information Processing", "Industrial", "Transportation", "Other")) + guides(fill = FALSE)
  } else if(variable == "ip"){
    multi_irf_plots(c("T50303_17_Q_1", "T50303_18_Q_1", "T50303_19_Q_1"), Conf_Int = TRUE, Title = "By Intellectual Property Type", irf_plots = irf_plots, invt_vars_exp = invt_vars_exp) + 
      theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
      theme(panel.border = element_blank(), axis.line = element_line()) + xlab("Quarters Ahead") + theme(legend.title = element_blank())  +
      scale_color_hue(labels = c("Software", "R&D", "Entertainment")) + guides(fill = FALSE) 
  } else if(variable == "gfcf_ci" | variable == "gfcf_pi"){
    multi_irf_plots(c("fof_gfcf_1", "fof_nc_nonres_gfcf_1"), Conf_Int = TRUE, Title = "GFCF",  irf_plots = irf_plots, invt_vars_exp = invt_vars_exp) + theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
      theme(panel.border = element_blank(), axis.line = element_line()) + xlab("Quarters Ahead") + theme(legend.title = element_blank()) +
      scale_color_hue(labels = c("Corporate", "Noncorporate")) + guides(fill = FALSE)
  } else if(variable == "fof_tot_ci" | variable == "fof_tot_pi"){
    multi_irf_plots(c("fof_net_all_cc_1", "fof_nc_net_all_cc_1"), Conf_Int = TRUE, Title = "Total Investment", irf_plots = irf_plots, invt_vars_exp = invt_vars_exp) + theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
      theme(panel.border = element_blank(), axis.line = element_line()) + xlab("Quarters Ahead") + theme(legend.title = element_blank()) +
      scale_color_hue(labels = c("Corporate", "Noncorporate")) + guides(fill = FALSE)
  } else if(variable == "fof_struct_ci" | variable == "fof_struct_pi"){
    multi_irf_plots(c("fof_net_struct_cc_1", "fof_nc_net_struct_cc_1"), Conf_Int = TRUE, Title = "Structures", irf_plots = irf_plots, invt_vars_exp = invt_vars_exp) + theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
      theme(panel.border = element_blank(), axis.line = element_line()) + xlab("Quarters Ahead") + theme(legend.title = element_blank()) +
      scale_color_hue(labels = c("Corporate", "Noncorporate")) + guides(fill = FALSE)
  } else if(variable == "fof_equip_ci" | variable == "fof_equip_pi"){
    multi_irf_plots(c("fof_net_equip_cc_1", "fof_nc_net_equip_cc_1"), Conf_Int = TRUE, Title = "Equipment", irf_plots = irf_plots, invt_vars_exp = invt_vars_exp) + theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
      theme(panel.border = element_blank(), axis.line = element_line()) + xlab("Quarters Ahead") + theme(legend.title = element_blank()) +
      scale_color_hue(labels = c("Corporate", "Noncorporate")) + guides(fill = FALSE)
  } else if(variable == "fof_intan_ci" | variable == "fof_intan_pi"){
    multi_irf_plots(c("fof_net_intan_cc_1", "fof_nc_net_ip_cc_1"), Conf_Int = TRUE, Title = "Intellectual Property", irf_plots = irf_plots, invt_vars_exp = invt_vars_exp) + theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
      theme(panel.border = element_blank(), axis.line = element_line()) + xlab("Quarters Ahead") + theme(legend.title = element_blank()) +
      scale_color_hue(labels = c("Corporate", "Noncorporate")) + guides(fill = FALSE)
  } else if(variable == "faat_tot_pi" | variable == "faat_tot_ci"){
    multi_irf_plots(c("FAAt407_37_A_KQ_1", "FAAt407_41_A_KQ_1"), Conf_Int = TRUE, Title = "Total Investment", irf_plots = irf_plots, invt_vars_exp = invt_vars_exp) + theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
      theme(panel.border = element_blank(), axis.line = element_line()) + xlab("Quarters Ahead") + theme(legend.title = element_blank()) +
      scale_color_hue(labels = c("Corporate", "Noncorporate")) + guides(fill = FALSE)
  } else if(variable == "faat_equip_pi" | variable == "faat_equip_ci"){
    multi_irf_plots(c("FAAt407_38_A_KQ_1", "FAAt407_42_A_KQ_1"), Conf_Int = TRUE, Title = "Equipment", irf_plots = irf_plots, invt_vars_exp = invt_vars_exp) + theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
      theme(panel.border = element_blank(), axis.line = element_line()) + xlab("Quarters Ahead") + theme(legend.title = element_blank()) +
      scale_color_hue(labels = c("Corporate", "Noncorporate")) + guides(fill = FALSE)
  } else if(variable == "faat_struct_pi" | variable == "faat_struct_ci"){
    multi_irf_plots(c("FAAt407_39_A_KQ_1", "FAAt407_43_A_KQ_1"), Conf_Int = TRUE, Title = "Structures", irf_plots = irf_plots, invt_vars_exp = invt_vars_exp) + theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
      theme(panel.border = element_blank(), axis.line = element_line()) + xlab("Quarters Ahead") + theme(legend.title = element_blank()) +
      scale_color_hue(labels = c("Corporate", "Noncorporate")) + guides(fill = FALSE)
  } else if(variable == "faat_intan_ci" | variable == "faat_intan_pi"){
    multi_irf_plots(c("FAAt407_40_A_KQ_1", "FAAt407_44_A_KQ_1"), Conf_Int = TRUE, Title = "Intellectual Property", irf_plots = irf_plots, invt_vars_exp = invt_vars_exp) + theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
      theme(panel.border = element_blank(), axis.line = element_line()) + xlab("Quarters Ahead") + theme(legend.title = element_blank()) +
      scale_color_hue(labels = c("Corporate", "Noncorporate")) + guides(fill = FALSE)
  } else if(variable == "gdp_split"){
    multi_irf_plots(c("GDP_1", "GDP_2"), Conf_Int = TRUE, Title = "GDP", irf_plots = irf_plots, invt_vars_exp = invt_vars_exp) + theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
      theme(panel.border = element_blank(), axis.line = element_line()) + xlab("Quarters Ahead") + theme(legend.title = element_blank()) +
      scale_color_hue(labels = c("Positive Shock", "Negative Shock")) + guides(fill = FALSE)
  } else if(variable == "gpdi_split"){
    multi_irf_plots(c("GPDI_1", "GPDI_2"), Conf_Int = TRUE, Title = "GPDI", irf_plots = irf_plots, invt_vars_exp = invt_vars_exp)+ theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
      theme(panel.border = element_blank(), axis.line = element_line()) + xlab("Quarters Ahead") + theme(legend.title = element_blank()) +
      scale_color_hue(labels = c("Positive Shock", "Negative Shock")) + guides(fill = FALSE)
  } else if(variable == "fi_split"){
    multi_irf_plots(c("FI_1", "FI_2"), Conf_Int = TRUE, Title = "Fixed Investment", irf_plots = irf_plots, invt_vars_exp = invt_vars_exp)+ theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
      theme(panel.border = element_blank(), axis.line = element_line()) + xlab("Quarters Ahead") + theme(legend.title = element_blank()) +
      scale_color_hue(labels = c("Positive Shock", "Negative Shock")) + guides(fill = FALSE)
  } else if(variable == "nonres_split"){
    multi_irf_plots(c("NONRES_1", "NONRES_2"), Conf_Int = TRUE, Title = "Nonresidential Investment", irf_plots = irf_plots, invt_vars_exp = invt_vars_exp)+ theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
      theme(panel.border = element_blank(), axis.line = element_line()) + xlab("Quarters Ahead") + theme(legend.title = element_blank()) +
      scale_color_hue(labels = c("Positive Shock", "Negative Shock")) + guides(fill = FALSE)
  } else if(variable == "res_split"){
    multi_irf_plots(c("RES_1", "RES_2"), Conf_Int = TRUE, Title = "Residential Investment", irf_plots = irf_plots, invt_vars_exp = invt_vars_exp)+ theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
      theme(panel.border = element_blank(), axis.line = element_line()) + xlab("Quarters Ahead") + theme(legend.title = element_blank()) +
      scale_color_hue(labels = c("Positive Shock", "Negative Shock")) + guides(fill = FALSE)
  }
}

split_rr <- function(variable, title, split){
  irf_plots <- list()
  romerdata_q_b <- romerdata_q %>% filter(Date < split)
  romerdata_q_a <- romerdata_q %>% filter(Date >= split)
  
  v1 <- var_ts(variable, "EXOGENRRATIO", 1, 4, GDP = TRUE, trans_negs = FALSE, romerdata_q_b) 
  colnames(v1)[colnames(v1) == "ts_invt"] <- variable # rename TS column names
  irf <- run_var_irf(v1, variable, 20) # run VAR and get IRF
  irf <- extract_varirf(irf, "EXOGENRRATIO", "Q") # get IRF in readable format
  plot <- plot_irf(irf, variable, "EXOGENRRATIO") # plot IRF
  
  irf_plots[[1]] <- plot # save plot
  
  v1 <- var_ts(variable, "EXOGENRRATIO", 1, 4, GDP = TRUE, trans_negs = FALSE, romerdata_q_a) 
  colnames(v1)[colnames(v1) == "ts_invt"] <- variable # rename TS column names
  irf <- run_var_irf(v1, variable, 20) # run VAR and get IRF
  irf <- extract_varirf(irf, "EXOGENRRATIO", "Q") # get IRF in readable format
  plot <- plot_irf(irf, variable, "EXOGENRRATIO") # plot IRF
  irf_plots[[2]] <- plot
  invt_vars_exp <- c(paste(variable, "1", sep = "_"), paste(variable, "2", sep = "_"))
    
  multi_irf_plots(all_of(invt_vars_exp), Conf_Int = TRUE, Title = title, irf_plots = irf_plots, invt_vars_exp = invt_vars_exp) + theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
      theme(panel.border = element_blank(), axis.line = element_line()) + xlab("Quarters Ahead") + theme(legend.title = element_blank()) +
      scale_color_hue(labels = c("Pre-1976", "Post-1976")) + guides(fill = FALSE)
}


fig2 <- function(int){
    intan <- nipa_a %>% mutate(intanr = T10105_12_A/T10105_9_A, 
                               structr = T10105_10_A/T10105_9_A,
                               equipr = T10105_11_A/T10105_9_A)
    ggplot(data = intan) + geom_line(aes(x = date, y = intanr, colour = "Intangibles"), size = 1.1) +
      geom_line(aes(x = date, y = structr, colour = "Structures"), size = 1.1) +
      geom_line(aes(x = date, y = equipr, colour = "Equipment"), size = 1.1) + 
      ylab("Share of Nonresidential Investment") + xlab("Year") + theme_minimal() +
      theme(legend.position=c(0.85,0.15)) + theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
      theme(panel.border = element_blank(), axis.line = element_line(), legend.title = element_blank()) + 
      scale_color_manual(values = c("Structures" = "red", "Equipment" = "darkgreen", "Intangibles" = "blue"),
                         limits = c("Equipment", "Structures", "Intangibles"))
}

#Function that replicate Proxy SVAR from M-R. Takes a list of four objects. First is 
# a nxm matrix (dataset) with m variables to be estimated and n rows. Second is the impulse response
#horizon, third contains the number of lags, and fourth is a nxk matrix with k proxies. the order in which
# the proxies are ordered (var_order = 1 for pi shock ordered first and var_order = 2 for
# CI shock ordered first. flip == TRUE gives response to a one percentage point increase
# in either tax rate while false gives the response to a decrease.
doProxySVAR <- function(VAR, var_order, flip){
  X1 <- dplyr::lag(VAR$dataset, 1)
  X2 <- dplyr::lag(VAR$dataset, 2)
  X3 <- dplyr::lag(VAR$dataset, 3)
  X4 <- dplyr::lag(VAR$dataset, 4)
  X <- cbind(X1, X2, X3, X4)
  X <- X[(VAR$lags + 1):nrow(X), ]
  Y <- VAR$dataset[(VAR$lags + 1):nrow(VAR$dataset), ]
  VAR_k <- ncol(VAR$proxies)
  VAR_m <- VAR$proxies[(VAR$lags + 1):nrow(VAR$proxies), ]
  VAR_t <- nrow(Y)
  VAR_n <- ncol(Y)
  
  # Run VAR
  X_ones <- cbind(X, rep(1, nrow(X)))
  X_ones_m <- cbind(X, rep(1, nrow(VAR_m)))
  VAR_bet <- mldivide(X_ones,Y)
  VAR_res <- Y - X_ones%*%VAR_bet
  VAR_bet <- mldivide(X_ones_m,Y)
  VAR_res <- Y - X_ones_m%*%VAR_bet
  
  VAR_Sigma <- (t(VAR_res)%*%VAR_res)/drop(VAR_t - VAR_n %*% VAR$lags - 1)
  
  ## Identification
  
  Phib <- mldivide(cbind(rep(1, nrow(VAR_m)), VAR_m), VAR_res)
  Phib <- Phib[2:nrow(Phib), ]
  Phib11 <- Phib[1:VAR_k, 1:VAR_k]
  Phib21 <- Phib[1:VAR_k, (VAR_k+1):VAR_n]
  b21ib11 <- t(mldivide(Phib11, Phib21))
  Sig11 <- VAR_Sigma[1:VAR_k,1:VAR_k]
  Sig21 <- VAR_Sigma[(VAR_k+1):VAR_n, 1:VAR_k]
  Sig22 <- VAR_Sigma[(VAR_k+1):VAR_n, (VAR_k+1):VAR_n]
  ZZp <- b21ib11%*%Sig11%*%t(b21ib11) - (Sig21%*%t(b21ib11) + b21ib11%*%t(Sig21)) + Sig22
  b12b12p <- t(Sig21 - b21ib11%*%Sig11) %*% mldivide(ZZp, Sig21 - b21ib11 %*% Sig11)
  b11b11p <- Sig11 - b12b12p
  b22b22p <- Sig22 + b21ib11%*% (b12b12p - Sig11)%*%t(b21ib11)
  b12ib22 <- mrdivide(t(Sig21 - b21ib11 %*% Sig11)+b12b12p %*% t(b21ib11),t(b22b22p))
  b11iSig <- mrdivide(diag(VAR_k),diag(VAR_k)-b12ib22 %*% b21ib11)
  b21iSig <- b21ib11%*%b11iSig
  SIG <- mldivide(b11iSig, b11b11p)
  SigmaTSigmaTp <- mrdivide(SIG, t(b11iSig))
  
  # Reliability
  
  Sigmm <- t(VAR_m)%*%VAR_m/drop(VAR_t)
  ED <- diag(VAR_k)*sum(rowSums(VAR_m) != 0)/VAR_t
  mu1 <- t(VAR_m)%*%VAR_res[ , 1:VAR_k]/VAR_t
  PhiPhip <- mu1%*%solve(b11b11p) %*%t(mu1)
  VAR_RM <- solve(Sigmm)%*%PhiPhip%*%solve(ED)
  VAR_RMeigs <- sort(eigen(VAR_RM)$values)
  
  #Impulse Responses
  VAR_b1 <- array(numeric(),c(ncol(VAR$dataset),2,2)) 
  VAR_irs <- array(numeric(), c(VAR$iphor, ncol(VAR$dataset), 2))
  var_irs_list <- list()
  for(i in 1:VAR_k){
    if(var_order == 1){
      s1 <- sqrt(SigmaTSigmaTp[1,1])
      a <- SigmaTSigmaTp[2,1]/s1
      s2 <- sqrt(SigmaTSigmaTp[2,2] - a^2)
      SigmaT <- rbind(cbind(s1, 0), cbind(a, s2))
    } else {
      s2 <- sqrt(SigmaTSigmaTp[2,2])
      b <- SigmaTSigmaTp[1,2]/s2
      s1 <-sqrt(SigmaTSigmaTp[1,1] - b^2)
      SigmaT <- rbind(cbind(s1, b), cbind(0, s2))
    }
    irs <- matrix(0, nrow = 24, ncol = ncol(VAR$dataset))
    VAR_b1[, ,i] <- rbind(b11iSig, b21iSig)%*%SigmaT
    irs[VAR$lags+1, ] <- -VAR_b1[, i, i]/VAR_b1[i,i,i]
    for(j in 2:VAR$iphor){
      lvars <- t(irs[seq(from = VAR$lags + j - 1, to = j, by = -1),])
      irs[VAR$lags+j, ] <- t(as.vector(lvars)) %*% VAR_bet[1:(VAR$lags*VAR_n),]
    }
    VAR_irs[1:20,1:VAR_n,i] <- irs[(VAR$lags+1):nrow(irs),]
    
    var_irs_list[[i]] <- VAR_irs[, , i]
    colnames(var_irs_list[[i]]) <- colnames(VAR$dataset)
    if("PITB" %in% colnames(VAR$dataset)){
      or_taxb_PI <- match("PITB", colnames(VAR$dataset))
      or_taxr_PI <- match("APITR", colnames(VAR$dataset))
      var_irs_list[[i]] <- cbind(var_irs_list[[i]],
                                 (var_irs_list[[i]][, or_taxr_PI]/0.1667 + var_irs_list[[i]][or_taxb_PI]))
      colnames(var_irs_list[[i]])[ncol(var_irs_list[[i]])] <- "PITREV"
    } else if("CITB" %in% colnames(VAR$dataset)){
      or_taxb_CI <- match("CITB", colnames(VAR$dataset))
      or_taxr_CI <- match("ACITR", colnames(VAR$dataset))
      var_irs_list[[i]] <- cbind(var_irs_list[[i]], (var_irs_list[[i]][, or_taxr_CI]/0.2996 + var_irs_list[[i]][, or_taxb_CI])) 
      colnames(var_irs_list[[i]])[ncol(var_irs_list[[i]])] <- "CITREV"
    } else if("PLEVEL" %in% colnames(VAR$dataset)){
      or_plevel <- match("PLEVEL", colnames(VAR$dataset))
      var_irs_list[[i]] <- cbind(var_irs_list[[i]], 
                                 4*(var_irs_list[[i]][, or_plevel] - append(0, var_irs_list[[i]][1:(nrow(var_irs_list[[i]]) - 1), or_plevel])))
      colnames(var_irs_list[[i]])[ncol(var_irs_list[[i]])] <- "INFL"
    } else if("EMP" %in% colnames(VAR$dataset)){
      or_emp <- match("EMP", colnames(VAR$dataset))
      or_LF <- match("LF", colnames(VAR$dataset))
      var_irs_list[[i]] <- cbind(var_irs_list[[i]],
                                 (1- 0.9475)*(exp(-0.9475/(1- 0.9475)*(var_irs_list[[i]][, or_emp] -
                                                                         var_irs_list[[i]][, or_LF])/100) - 1 )*100)
      colnames(var_irs_list[[i]])[ncol(var_irs_list[[i]])] <- "UNR"
    }
  }
  var_irs_list[[VAR_k + 1]] <- VAR_RMeigs
  if(flip == TRUE){
    var_irs_list[[1]] <- var_irs_list[[1]]*-1
    var_irs_list[[2]] <- var_irs_list[[2]]*-1
  } else{
    var_irs_list <- var_irs_list
  }
  
  return(var_irs_list)
}

#Replicates M-R wild bootstrap CI function. Takes a list (VAR) defined as in the
#doProxySVAR function above, the number of runs (nboot), a confidence level (clevel)
# that can be a vector (i.e., clevel = 68 or clevel = c(68, 90)), and the order in which
# the proxies are ordered (var_order = 1 for pi shock ordered first and var_order = 2 for
# CI shock ordered first.)
doProxySVARBootstrap <- function(VAR, nboot, clevel, var_order, flip){
  jj = 1
  VAR_k <- ncol(VAR$proxies)
  numcol <- ncol(doProxySVAR(VAR, var_order = 1, flip = FALSE)[[1]])
  dim1 <- c(length(c(doProxySVAR(VAR, var_order = 1, flip = FALSE)[[1]])))
  EIGS <- matrix(0, nrow = length(1:nboot), ncol = 2)
  IRS <- array(0, c(dim1, length(1:nboot), length(1:VAR_k)))
  VARbs_irsH <- array(0, c(VAR$iphor, numcol, VAR_k, length(clevel)))
  VARbs_irsL <- array(0, c(VAR$iphor, numcol, VAR_k, length(clevel)))
  X1 <- dplyr::lag(VAR$dataset, 1)
  X2 <- dplyr::lag(VAR$dataset, 2)
  X3 <- dplyr::lag(VAR$dataset, 3)
  X4 <- dplyr::lag(VAR$dataset, 4)
  X <- cbind(X1, X2, X3, X4)
  X <- X[(VAR$lags + 1):nrow(X), ]
  Y <- VAR$dataset[(VAR$lags + 1):nrow(VAR$dataset), ]
  VAR_k <- ncol(VAR$proxies)
  VAR_m <- VAR$proxies[(VAR$lags + 1):nrow(VAR$proxies), ]
  VAR_t <- nrow(Y)
  VAR_n <- ncol(Y)
  
  # Run VAR
  X_ones <- cbind(X, rep(1, nrow(X)))
  X_ones_m <- cbind(X, rep(1, nrow(VAR_m)))
  VAR_bet <- mldivide(X_ones,Y)
  VAR_res <- Y - X_ones%*%VAR_bet
  VAR_bet <- mldivide(X_ones_m,Y)
  VAR_res <- Y - X_ones_m%*%VAR_bet
  
  res <- detrend(VAR_res, tt= "linear")
  
  while(jj < nboot + 1){
    rr <- 1-2*(runif(VAR_t) > 0.5)
    resb <- t(res*(rr%*%t(rep(1, VAR_n))))
    
    varsb <- matrix(0, nrow = VAR$lags + VAR_t, ncol = VAR_n)
    varsb[1:VAR$lags,] <- VAR$dataset[1:VAR$lags,]
    
    for(tt in (VAR$lags+1):(VAR$lags+VAR_t)){
      lvars <- t(varsb[seq(from = tt-1, to = tt-VAR$lags, by = -1),])
      varsb[tt, ] <- t(as.vector(lvars)) %*%VAR_bet[1:(VAR$lags*VAR_n),] + VAR_bet[(VAR$lags*VAR_n + 1):nrow(VAR_bet),] + t(resb[,tt-VAR$lags])
    }
    
    VARbs <- VAR
    VARbs$dataset <- varsb
    colnames(VARbs$dataset) <- colnames(VAR$dataset)
    VARbs$proxies <- rbind(VAR$proxies[1:VAR$lags,],VAR_m*(rr%*%t(rep(1,VAR_k))))
    irs_list_sv <- doProxySVAR(VARbs, var_order = var_order, flip = FALSE)
    
    for(i in 1:VAR_k){
      irs <- irs_list_sv[[i]]
      IRS[ , jj, i] <- as.vector(irs)
    }
    EIGS[jj,] <- irs_list_sv[[VAR_k + 1]]
    jj = jj + 1
  }
  colnames_var <- colnames(irs_list_sv[[1]])
  for(j in 1:length(clevel)){
    for(i in 1:VAR_k){
      VARbs_irsH[,,i,j] <- matrix(colQuantiles(t(IRS[,,i]), probs = (1-clevel[j]/100)/2), nrow = 20, ncol = length(colnames_var))
      VARbs_irsL[,,i,j] <- matrix(colQuantiles(t(IRS[,,i]), probs = 1-(1-clevel[j]/100)/2), nrow = 20, ncol = length(colnames_var))
    }
  }  
  
  eigs_list <- list()
  for(i in 1:length(clevel)){
    eigs_list[[i]] <- cbind(colQuantiles(EIGS, probs =  (1-clevel/100)/2), 
                            colQuantiles(EIGS, probs =  1-(1-clevel/100)/2))
  }
  
  if(flip == TRUE){
    VARbs_irsH <- VARbs_irsH * -1
    VARbs_irsL <- VARbs_irsL * -1
  } else{
    
  }
  
  bounds <- list()
  colnames(VARbs_irsH) <- colnames_var
  colnames(VARbs_irsL) <- colnames_var
  bounds[[1]] <- VARbs_irsH
  bounds[[2]] <- VARbs_irsL
  bounds[[3]] <- eigs_list[[1]]
  return(bounds)
}

# Replicate figures 9 and 10 in M-R. Takes list object VAR (as defined for doProxySVAR)
# number of runs, clevel (can be a vector), the response variable as a string.
# PI_CUT = 1 gives response to a PI shock; PI_CUT = 0 gives response to a CI shock. var_order
# determines which shock ordered first (var_order = 1 gives PI shock first, var_order = 2
# gives CI shock first.)
mr_plot_fig910 <- function(VAR, nboot, clevel, var, PI_CUT, var_order){
  VAR01 <- VAR
  VAR01_OUT <- doProxySVAR(VAR01, var_order, flip = TRUE)
  VAR01_BS <- doProxySVARBootstrap(VAR01, nboot, clevel, var_order, flip = TRUE)
  
  rel_col <- match(var, colnames(VAR01_OUT[[1]]))
  
  periods_ahead <- seq(from = 1, to = VAR01$iphor)
  if(PI_CUT == 1){
    vals <- VAR01_OUT[[1]][,rel_col]
    if(length(clevel) == 1){
      lower_vals <- VAR01_BS[[1]][,,1,1][,rel_col]
      upper_vals <- VAR01_BS[[2]][,,1,1][,rel_col]
      plot_df <- as.data.frame(cbind(periods_ahead, vals, lower_vals, upper_vals))
      ggplot(data = plot_df, aes(x = periods_ahead)) + 
        geom_line(aes(y = vals), size = 1.1, color = "blue") +
        geom_line(aes(y = lower_vals), linetype = "dashed", color = "blue") +
        geom_line(aes(y = upper_vals), linetype = "dashed", color = "blue")  +
        geom_hline(aes(yintercept = 0), size = 1.1) + theme_minimal() +
        theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
        theme(panel.border = element_blank(), axis.line = element_line()) + 
        theme(legend.title = element_blank(), legend.position =c(0.8,1)) + ylab("Percent") + xlab("Quarters") +
        #scale_color_manual(values = c("blue", "red"), labels = c("APITR Ordered First", "ACITR Ordered First")) +
        ggtitle(paste("PI Shock to ", var))
    } else if(length(clevel) == 2){
      
      lower_vals_95 <- VAR01_BS[[1]][,,1,1][,rel_col]
      lower_vals_90 <- VAR01_BS[[1]][,,1,2][,rel_col]
      upper_vals_95 <- VAR01_BS[[2]][,,1,1][,rel_col]
      upper_vals_90 <- VAR01_BS[[2]][,,1,2][,rel_col]
      plot_df <- as.data.frame(cbind(periods_ahead, vals, upper_vals_95, lower_vals_95,
                                     upper_vals_90, lower_vals_90))
      ggplot(data = plot_df, aes(x = periods_ahead)) + 
        geom_line(aes(y = vals), size = 1.1, color = "blue") +
        geom_line(aes(y = lower_vals_95), linetype = "dashed", color = "blue") +
        geom_line(aes(y = upper_vals_95), linetype = "dashed", color = "blue") +
        geom_line(aes(y = lower_vals_90), linetype = "dashed", color = "blue") +
        geom_line(aes(y = upper_vals_90), linetype = "dashed", color = "blue") +
        geom_hline(aes(yintercept = 0), size = 1.1) + theme_minimal() +
        theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
        theme(panel.border = element_blank(), axis.line = element_line()) + 
        theme(legend.title = element_blank(), legend.position =c(0.8,1)) + ylab("Percent") + xlab("Quarters") +
        #scale_color_manual(values = c("blue", "red"), labels = c("APITR Ordered First", "ACITR Ordered First")) +
        ggtitle(paste("PI Shock to ", var))
    }
  } else if(PI_CUT == 0){
    vals <- VAR01_OUT[[2]][,rel_col]
    if(length(clevel) == 1){
      lower_vals <- VAR01_BS[[1]][,,2,1][,rel_col]
      upper_vals <- VAR01_BS[[2]][,,2,1][,rel_col]
      plot_df <- as.data.frame(cbind(periods_ahead, vals, lower_vals, upper_vals))
      ggplot(data = plot_df, aes(x = periods_ahead)) + 
        geom_line(aes(y = vals), size = 1.1, color = "blue") +
        geom_line(aes(y = lower_vals), linetype = "dashed", color = "blue") +
        geom_line(aes(y = upper_vals), linetype = "dashed", color = "blue")  +
        geom_hline(aes(yintercept = 0), size = 1.1) + theme_minimal() +
        theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
        theme(panel.border = element_blank(), axis.line = element_line()) + 
        theme(legend.title = element_blank(), legend.position =c(0.8,1)) + ylab("Percent") + xlab("Quarters") +
        #scale_color_manual(values = c("blue", "red"), labels = c("APITR Ordered First", "ACITR Ordered First")) +
        ggtitle(paste("CI Shock to ", var))
    } else if(length(clevel) == 2){
      lower_vals_95 <- VAR01_BS[[1]][,,2,1][,rel_col]
      lower_vals_90 <- VAR01_BS[[1]][,,2,2][,rel_col]
      upper_vals_95 <- VAR01_BS[[2]][,,2,1][,rel_col]
      upper_vals_90 <- VAR01_BS[[2]][,,2,2][,rel_col]
      plot_df <- as.data.frame(cbind(periods_ahead, vals, upper_vals_95, lower_vals_95,
                                     upper_vals_90, lower_vals_90))
      ggplot(data = plot_df, aes(x = periods_ahead)) + 
        geom_line(aes(y = vals), size = 1.1, color = "blue") +
        geom_line(aes(y = lower_vals_95), linetype = "dashed", color = "blue") +
        geom_line(aes(y = upper_vals_95), linetype = "dashed", color = "blue") +
        geom_line(aes(y = lower_vals_90), linetype = "dashed", color = "blue") +
        geom_line(aes(y = upper_vals_90), linetype = "dashed", color = "blue") +
        geom_hline(aes(yintercept = 0), size = 1.1) + theme_minimal() +
        theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
        theme(panel.border = element_blank(), axis.line = element_line()) + 
        theme(legend.title = element_blank(), legend.position =c(0.8,1)) + ylab("Percent") + xlab("Quarters") +
        #scale_color_manual(values = c("blue", "red"), labels = c("APITR Ordered First", "ACITR Ordered First")) +
        ggtitle(paste("CI Shock to ", var))
    }
  }
}

#Replicates figure 4 in M-R. VAR, nboot, clevel, var, and PI_CUT defined as above,
#but clevel cannot be vectorized.
mr_plot_fig4 <- function(VAR, nboot, clevel, var, PI_CUT){
  # APITR ordered first
  VAR01 <- VAR
  VAR01_OUT <- doProxySVAR(VAR01, var_order = 1, flip = FALSE)
  VAR01_BS <- doProxySVARBootstrap(VAR01, nboot, clevel, var_order = 1, flip = FALSE)
  
  # ACITR Ordered first
  VAR02 <- VAR_FIG4
  VAR02_OUT <- doProxySVAR(VAR02, var_order = 2, flip = FALSE)
  VAR02_BS <- doProxySVARBootstrap(VAR02, nboot, clevel, var_order = 2, flip = FALSE)
  
  rel_col <- match(var, colnames(VAR01_OUT[[1]]))
  
  #PI CUT
  
  if(PI_CUT == 1){
    periods_ahead <- seq(from = 1, to = VAR$iphor)
    vals <- VAR01_OUT[[1]][,rel_col]
    lower_vals <- VAR01_BS[[1]][,,1,][,rel_col]
    upper_vals <- VAR01_BS[[2]][,,1,][,rel_col]
    
    vals_c <- VAR02_OUT[[1]][,rel_col]
    lower_vals_c <- VAR02_BS[[1]][,,1,][,rel_col]
    upper_vals_c <- VAR02_BS[[2]][,,1,][,rel_col]
    plot_df <- as.data.frame(cbind(periods_ahead, vals, upper_vals, lower_vals, 
                                   vals_c, lower_vals_c, upper_vals_c))
    ggplot(data = plot_df, aes(x = periods_ahead)) + 
      geom_line(aes(y = vals), size = 1.1, color = "blue") +
      geom_line(aes(y = lower_vals, color = "blue"), linetype = "dashed") +
      geom_line(aes(y = upper_vals), linetype = "dashed", color = "blue") +
      geom_line(aes(y = vals_c, color = "red"), size = 1.1)  +
      geom_line(aes(y = lower_vals_c), linetype = "dashed", color = "red") +
      geom_line(aes(y = upper_vals_c), linetype = "dashed", color = "red") +
      geom_hline(aes(yintercept = 0), size = 1.1) + theme_minimal() +
      theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
      theme(panel.border = element_blank(), axis.line = element_line()) + 
      theme(legend.title = element_blank(), legend.position =c(0.8,1)) + ylab("Percent") + xlab("Quarters") +
      scale_color_manual(values = c("blue", "red"), labels = c("APITR Ordered First", "ACITR Ordered First")) +
      ggtitle(paste("PI Shock to ", var))
  } else if(PI_CUT == 0){
    periods_ahead <- seq(from = 1, to = VAR$iphor)
    vals <- VAR01_OUT[[2]][,rel_col]
    lower_vals <- VAR01_BS[[1]][,,2,][,rel_col]
    upper_vals <- VAR01_BS[[2]][,,2,][,rel_col]
    
    vals_c <- VAR02_OUT[[2]][,rel_col]
    lower_vals_c <- VAR02_BS[[1]][,,2,][,rel_col]
    upper_vals_c <- VAR02_BS[[2]][,,2,][,rel_col]
    plot_df <- as.data.frame(cbind(periods_ahead, vals, upper_vals, lower_vals, 
                                   vals_c, lower_vals_c, upper_vals_c))
    ggplot(data = plot_df, aes(x = periods_ahead)) + 
      geom_line(aes(y = vals), size = 1.1, color = "blue") +
      geom_line(aes(y = lower_vals, color = "blue"), linetype = "dashed") +
      geom_line(aes(y = upper_vals), linetype = "dashed", color = "blue") +
      geom_line(aes(y = vals_c, color = "red"), size = 1.1)  +
      geom_line(aes(y = lower_vals_c), linetype = "dashed", color = "red") +
      geom_line(aes(y = upper_vals_c), linetype = "dashed", color = "red") +
      geom_hline(aes(yintercept = 0), size = 1.1) + theme_minimal() +
      theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
      theme(panel.border = element_blank(), axis.line = element_line()) + 
      theme(legend.title = element_blank(), legend.position =c(0.8,1)) + ylab("Percent") + xlab("Quarters") +
      scale_color_manual(values = c("blue", "red"), labels = c("APITR Ordered First", "ACITR Ordered First")) +
      ggtitle(paste("CI Shock to ", var))
  }
}

# Plotting function for Proxy SVAR impulse responses. Takes a list object for which the 
# ith element contains a ggplot_build object for an impulse response as plotted using
# mr_plot_fig910. Used to combined impulse responses. var gives the title of the resulting plot.
# var1-var5 defines the variables for which impulse responses are computed and plotted.
# num_vars gives the number of variables plotted.
plot_i5 <- function(ggplot_list, var, var1, var2, var3, var4, var5, num_vars){
  Quarters <- as.numeric(seq(1,20))
  y <- as.numeric(ggplot_list[[1]]$data[[1]]$y)
  ymin <- as.numeric(ggplot_list[[1]]$data[[2]]$y)
  ymax <- as.numeric(ggplot_list[[1]]$data[[3]]$y)
  variable <- rep(var1, 20)
  df1 <- cbind(Quarters, y, ymin, ymax, variable)
  
  if(num_vars == 2){
    y <- as.numeric(ggplot_list[[2]]$data[[1]]$y)
    ymin <- as.numeric(ggplot_list[[2]]$data[[2]]$y)
    ymax <- as.numeric(ggplot_list[[2]]$data[[3]]$y)
    variable <- rep(var2, 20)
    df2 <- cbind(Quarters, y, ymin, ymax, variable)
    
    df <- as.data.frame(rbind(df1, df2)) %>%
      mutate(y = as.numeric(y), Quarters = as.numeric(Quarters), ymin = as.numeric(ymin), ymax = as.numeric(ymax))
  } else if(num_vars == 3){
    y <- as.numeric(ggplot_list[[2]]$data[[1]]$y)
    ymin <- as.numeric(ggplot_list[[2]]$data[[2]]$y)
    ymax <- as.numeric(ggplot_list[[2]]$data[[3]]$y)
    variable <- rep(var2, 20)
    df2 <- cbind(Quarters, y, ymin, ymax, variable)
    y <- as.numeric(ggplot_list[[3]]$data[[1]]$y)
    ymin <- as.numeric(ggplot_list[[3]]$data[[2]]$y)
    ymax <- as.numeric(ggplot_list[[3]]$data[[3]]$y)
    variable <- rep(var3, 20)
    df3 <- cbind(Quarters, y, ymin, ymax, variable)
    
    df <- as.data.frame(rbind(df1, df2, df3)) %>%
      mutate(y = as.numeric(y), Quarters = as.numeric(Quarters), ymin = as.numeric(ymin), ymax = as.numeric(ymax))
  } else if(num_vars == 4){
    y <- as.numeric(ggplot_list[[2]]$data[[1]]$y)
    ymin <- as.numeric(ggplot_list[[2]]$data[[2]]$y)
    ymax <- as.numeric(ggplot_list[[2]]$data[[3]]$y)
    variable <- rep(var2, 20)
    df2 <- cbind(Quarters, y, ymin, ymax, variable)
    y <- as.numeric(ggplot_list[[3]]$data[[1]]$y)
    ymin <- as.numeric(ggplot_list[[3]]$data[[2]]$y)
    ymax <- as.numeric(ggplot_list[[3]]$data[[3]]$y)
    variable <- rep(var3, 20)
    df3 <- cbind(Quarters, y, ymin, ymax, variable)
    y <- as.numeric(ggplot_list[[4]]$data[[1]]$y)
    ymin <- as.numeric(ggplot_list[[4]]$data[[2]]$y)
    ymax <- as.numeric(ggplot_list[[4]]$data[[3]]$y)
    variable <- rep(var4, 20)
    df4 <- cbind(Quarters, y, ymin, ymax, variable)
    df <- as.data.frame(rbind(df1, df2, df3, df4)) %>%
      mutate(y = as.numeric(y), Quarters = as.numeric(Quarters), ymin = as.numeric(ymin), ymax = as.numeric(ymax))
  } else if(num_vars == 5){
    y <- as.numeric(ggplot_list[[2]]$data[[1]]$y)
    ymin <- as.numeric(ggplot_list[[2]]$data[[2]]$y)
    ymax <- as.numeric(ggplot_list[[2]]$data[[3]]$y)
    variable <- rep(var2, 20)
    df2 <- cbind(Quarters, y, ymin, ymax, variable)
    y <- as.numeric(ggplot_list[[3]]$data[[1]]$y)
    ymin <- as.numeric(ggplot_list[[3]]$data[[2]]$y)
    ymax <- as.numeric(ggplot_list[[3]]$data[[3]]$y)
    variable <- rep(var3, 20)
    df3 <- cbind(Quarters, y, ymin, ymax, variable)
    y <- as.numeric(ggplot_list[[4]]$data[[1]]$y)
    ymin <- as.numeric(ggplot_list[[4]]$data[[2]]$y)
    ymax <- as.numeric(ggplot_list[[4]]$data[[3]]$y)
    variable <- rep(var4, 20)
    df4 <- cbind(Quarters, y, ymin, ymax, variable)
    y <- as.numeric(ggplot_list[[5]]$data[[1]]$y)
    ymin <- as.numeric(ggplot_list[[5]]$data[[2]]$y)
    ymax <- as.numeric(ggplot_list[[5]]$data[[3]]$y)
    variable <- rep(var5, 20)
    df5 <- cbind(Quarters, y, ymin, ymax, variable)
    
    df <- as.data.frame(rbind(df1, df2, df3, df4, df5)) %>%
      mutate(y = as.numeric(y), Quarters = as.numeric(Quarters), ymin = as.numeric(ymin), ymax = as.numeric(ymax))
  }
  
  df %>% ggplot(aes(x = Quarters, y, fill = variable, colour = variable)) + 
    geom_ribbon(aes(ymin = ymin, ymax = ymax, group = variable),
                alpha = 0.2, linetype = 0) + geom_line(size = 1.1) + 
    geom_hline(yintercept = 0, color="black", size = 1.25) + ylab("Percent") + theme_minimal() +
    theme(legend.position="bottom") + 
    theme(legend.title = element_blank()) + ggtitle(paste(var)) +  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
    theme(panel.border = element_blank(), axis.line = element_line()) + xlab("Quarters Ahead")
}

# function for plotting impulse responses for a single variable (input as string)
# given a PI shock and a CI shock. runs gives the number of bootstraps, c_i gives the confidence
# interval. Calls plot_i5 to actually plot.
plot_ind_mr <- function(variable, runs, c_i){
  if(variable == "structures"){
    dataset <- mr_aer %>% dplyr::select(c('APITR','ACITR', 'GOV','RGDP','DEBT', 'INR','T50303_3_Q','CITB'))
    VAR1 <- list(dataset = as.matrix(dataset), 
                 lags = 4, 
                 iphor = 20, 
                 proxies = as.matrix(mr_aer %>%
                                       dplyr::select(c(m_PI, m_CI)))
    )
    #CI Cut
    ci <- ggplot_build(mr_plot_fig910(VAR = VAR1, nboot = runs, clevel = c_i, var = "T50303_3_Q", PI_CUT = 0, var_order = 2))
    # PI Cut
    pi <- ggplot_build(mr_plot_fig910(VAR = VAR1, nboot = runs, clevel = c_i, var = "T50303_3_Q", PI_CUT = 1, var_order = 1))
    struct_list <- list(ci, pi)
    plot_i5(struct_list, "Structures", var1 = "CI Shock", var2 = "PI Shock", num_vars = 2)
  } else if(variable == "equipment"){
    ## Equip
    dataset <- mr_aer %>% dplyr::select(c('APITR','ACITR', 'GOV','RGDP','DEBT', 'INR','T50303_9_Q','CITB'))
    VAR1 <- list(dataset = as.matrix(dataset), 
                 lags = 4, 
                 iphor = 20, 
                 proxies = as.matrix(mr_aer %>%
                                       dplyr::select(c(m_PI, m_CI)))
    )
    ## CI Cut
    ci <- ggplot_build(mr_plot_fig910(VAR = VAR1, nboot = runs, clevel = c_i, var = "T50303_9_Q", PI_CUT = 0, var_order = 2))
    ##PI Cut
    pi <- ggplot_build(mr_plot_fig910(VAR = VAR1, nboot = runs, clevel = c_i, var = "T50303_9_Q", PI_CUT = 1, var_order = 1))
    equip_list <- list(ci, pi)
    plot_i5(equip_list, "Equipment", var1 = "CI Shock", var2 = "PI Shock", num_vars = 2)
  } else if(variable == "ip"){
    dataset <- mr_aer %>% dplyr::select(c('APITR','ACITR', 'GOV','RGDP','DEBT', 'INR','T50303_16_Q','CITB'))
    VAR1 <- list(dataset = as.matrix(dataset), 
                 lags = 4, 
                 iphor = 20, 
                 proxies = as.matrix(mr_aer %>%
                                       dplyr::select(c(m_PI, m_CI)))
    )
    #CI CUT
    ci <- ggplot_build(mr_plot_fig910(VAR = VAR1, nboot = runs, clevel = c_i, var = "T50303_16_Q", PI_CUT = 0, var_order = 2))
    ##PI Cut
    pi <- ggplot_build(mr_plot_fig910(VAR = VAR1, nboot = runs, clevel = c_i, var = "T50303_16_Q", PI_CUT = 1, var_order = 1))
    ip_list <- list(ci, pi)
    plot_i5(ip_list, "Intellectual Property", var1 = "CI Shock", var2 = "PI Shock", num_vars = 2)
  }
}

# Function for plotting impulse responses for a particular variable split in time for
# a particular shock (e.g., GDP pre-1976 and GDP post-1976 on the same plot in response
# to a CI shock.) Takes variable as string. pi_cut = 1 for PI shock, pi_cut = 0 for CI
# shock. runs gives the number of bootstraps and c_i the confidence interval. Calls plot_i5
plot_time_split <- function(variable, pi_cut, runs, c_i){
  if(variable == "gdp"){
    dataset <- mr_aer %>% filter(Date < 1976) %>%
      dplyr::select(c('APITR','ACITR','GOV','RGDP','DEBT','FF','PLEVEL','NBR'))
    
    VAR1 <- list(dataset = as.matrix(dataset), 
                 lags = 4, 
                 iphor = 20, 
                 proxies = as.matrix(mr_aer %>% filter(Date < 1976) %>%
                                       dplyr::select(c(m_PI, m_CI)))
    )
    
    ci_b <- ggplot_build(mr_plot_fig910(VAR = VAR1, nboot = runs, clevel = c_i, var = "RGDP", PI_CUT = 0, var_order = 2))
    pi_b <- ggplot_build(mr_plot_fig910(VAR = VAR1, nboot = runs, clevel = c_i, var = "RGDP", PI_CUT = 1, var_order = 1))
    
    dataset <- mr_aer %>% filter(Date >= 1976) %>%
      dplyr::select(c('APITR','ACITR','GOV','RGDP','DEBT','FF','PLEVEL','NBR'))
    
    VAR1 <- list(dataset = as.matrix(dataset), 
                 lags = 4, 
                 iphor = 20, 
                 proxies = as.matrix(mr_aer %>% filter(Date >= 1976) %>%
                                       dplyr::select(c(m_PI, m_CI)))
    )
    ci_a <- ggplot_build(mr_plot_fig910(VAR = VAR1, nboot = runs, clevel = c_i, var = "RGDP", PI_CUT = 0, var_order = 2))
    pi_a <- ggplot_build(mr_plot_fig910(VAR = VAR1, nboot = runs, clevel = c_i, var = "RGDP", PI_CUT = 1, var_order = 1))
    gdp_ci_split <- list(ci_b, ci_a)
    gdp_pi_split <- list(pi_b, pi_a)
    if(pi_cut == 1){
      plot_i5(gdp_pi_split, "Output", "Pre-1976", "Post-1976", num_vars = 2)
    }else if(pi_cut == 0){
      plot_i5(gdp_ci_split, "Output", "Pre-1976", "Post-1976", num_vars = 2)
    }
  } else if(variable == "investment"){
    dataset <- mr_aer %>% filter(Date < 1976) %>%
      dplyr::select(c('APITR','ACITR', 'GOV','RGDP','DEBT', 'INR','IR','CITB'))
    VAR1 <- list(dataset = as.matrix(dataset), 
                 lags = 4, 
                 iphor = 20, 
                 proxies = as.matrix(mr_aer %>% filter(Date < 1976) %>%
                                       dplyr::select(c(m_PI, m_CI)))
    )
    
    ci_b <- ggplot_build(mr_plot_fig910(VAR = VAR1, nboot = runs, clevel = c_i, var = "INR", PI_CUT = 0, var_order = 1))
    pi_b <- ggplot_build(mr_plot_fig910(VAR = VAR1, nboot = runs, clevel = c_i, var = "INR", PI_CUT = 1, var_order = 2))
    
    dataset <- mr_aer %>% filter(Date >= 1976) %>%
      dplyr::select(c('APITR','ACITR', 'GOV','RGDP','DEBT', 'INR','IR','CITB'))
    VAR1 <- list(dataset = as.matrix(dataset), 
                 lags = 4, 
                 iphor = 20, 
                 proxies = as.matrix(mr_aer %>% filter(Date >= 1976) %>%
                                       dplyr::select(c(m_PI, m_CI)))
    )
    
    ci_a <- ggplot_build(mr_plot_fig910(VAR = VAR1, nboot = runs, clevel = c_i, var = "INR", PI_CUT = 0, var_order = 1))
    pi_a <- ggplot_build(mr_plot_fig910(VAR = VAR1, nboot = runs, clevel = c_i, var = "INR", PI_CUT = 1, var_order = 2))
    inr_ci_split <- list(ci_b, ci_a)
    inr_pi_split <- list(pi_b, pi_a)
    if(pi_cut == 1){
      plot_i5(inr_pi_split, "Nonresidential Investment", "Pre-1976", "Post-1976", num_vars = 2)
    } else if(pi_cut == 0){
      plot_i5(inr_ci_split, "Nonresidential Investment", "Pre-1976", "Post-1976", num_vars = 2)
    }
  }
}

# Plots same variable responses to different shocks given a start date. title input as
# string, variable as string, start_date as whole number. runs gives number of bootstraps.
two_svar_irf_inv <- function(variable, start_date, title, runs, c_i){
  dataset <- mr_aer %>% filter(Date >= start_date) %>%
    dplyr::select(c('APITR','ACITR', 'GOV','RGDP','DEBT', variable,'CITB'))
  VAR1 <- list(dataset = as.matrix(dataset), 
               lags = 4, 
               iphor = 20, 
               proxies = as.matrix(mr_aer %>% filter(Date >= start_date) %>%
                                     dplyr::select(c(m_PI, m_CI)))
  )
  ci <- ggplot_build(mr_plot_fig910(VAR = VAR1, nboot = runs, 
                                    clevel = c_i, var = variable, PI_CUT = 0, var_order = 2))
  pi <- ggplot_build(mr_plot_fig910(VAR = VAR1, nboot = runs, 
                                    clevel = c_i, var = variable, PI_CUT = 1, var_order = 1))
  rd_list <- list(ci, pi)
  plot_i5(rd_list, var = title, var1 = "CI Shock", var2 = "PI Shock", num_vars = 2)
}

#
plot_pos_neg_split <- function(type, pi_cut, runs, c_i){
  mr_aer_pos <- mr_aer %>% filter(Date >= 1975) %>%
    mutate(T_CI = ifelse(T_CI > 0, T_CI, 0),
           T_PI = ifelse(T_PI > 0, T_PI, 0),
           m_CI = ifelse(m_CI > 0, m_CI, 0),
           m_PI = ifelse(m_PI > 0, m_PI, 0))
  
  mr_aer_neg <- mr_aer %>% filter(Date >= 1975) %>%
    mutate(T_CI = ifelse(T_CI < 0, T_CI, 0),
           T_PI = ifelse(T_PI < 0, T_PI, 0),
           m_CI = ifelse(m_CI < 0, m_CI, 0),
           m_PI = ifelse(m_PI < 0, m_PI, 0))
  if(type == "gdp"){
    # Output
    dataset <- mr_aer_pos %>%
      dplyr::select(c('APITR','ACITR','GOV','RGDP','DEBT','FF','PLEVEL','NBR'))
    VAR1 <- list(dataset = as.matrix(dataset), 
                 lags = 4, 
                 iphor = 20, 
                 proxies = as.matrix(mr_aer_pos %>%
                                       dplyr::select(c(m_PI, m_CI)))
    )
    
    gdp_pos_c <- ggplot_build(mr_plot_fig910(VAR = VAR1, nboot = runs, clevel = c_i, var = "RGDP", PI_CUT = 0, var_order = 1))
    gdp_pos_p <- ggplot_build(mr_plot_fig910(VAR = VAR1, nboot = runs, clevel = c_i, var = "RGDP", PI_CUT = 1, var_order = 2))
    dataset <- mr_aer_neg %>%
      dplyr::select(c('APITR','ACITR','GOV','RGDP','DEBT','FF','PLEVEL','NBR'))
    VAR1 <- list(dataset = as.matrix(dataset), 
                 lags = 4, 
                 iphor = 20, 
                 proxies = as.matrix(mr_aer_neg %>%
                                       dplyr::select(c(m_PI, m_CI)))
    )
    gdp_neg_c <- ggplot_build(mr_plot_fig910(VAR = VAR1, nboot = runs, clevel = c_i, var = "RGDP", PI_CUT = 0, var_order = 2))
    gdp_neg_p <- ggplot_build(mr_plot_fig910(VAR = VAR1, nboot = runs, clevel = c_i, var = "RGDP", PI_CUT = 1, var_order = 2))
    gdp_p <- list(gdp_neg_p, gdp_pos_p)
    gdp_c <- list(gdp_neg_c, gdp_pos_c)
    if(pi_cut == 1){
      gdp_p[[2]]$data[[1]]$y <- -1*gdp_p[[2]]$data[[1]]$y
      gdp_p[[2]]$data[[2]]$y <- -1*gdp_p[[2]]$data[[2]]$y
      gdp_p[[2]]$data[[3]]$y <- -1*gdp_p[[2]]$data[[3]]$y
      plot_i5(ggplot_list = gdp_p, "PI Shock to GDP", var1 = "Negative Shock", var2 = "Positive Shock", num_vars = 2)
    } else if(pi_cut == 0){
      gdp_c[[2]]$data[[1]]$y <- -1*gdp_c[[2]]$data[[1]]$y
      gdp_c[[2]]$data[[2]]$y <- -1*gdp_c[[2]]$data[[2]]$y
      gdp_c[[2]]$data[[3]]$y <- -1*gdp_c[[2]]$data[[3]]$y
      plot_i5(ggplot_list = gdp_c, "CI Shock to GDP", var1 = "Negative Shock", var2 = "Positive Shock", num_vars = 2)    }
  } else if(type == "investment"){
    dataset <- mr_aer_pos %>%
      dplyr::select(c('APITR','ACITR', 'GOV','RGDP','DEBT', 'INR','IR','CITB'))
    VAR1 <- list(dataset = as.matrix(dataset), 
                 lags = 4, 
                 iphor = 20, 
                 proxies = as.matrix(mr_aer_pos %>%
                                       dplyr::select(c(m_PI, m_CI)))
    )
    ci_pos <- ggplot_build(mr_plot_fig910(VAR = VAR1, nboot = runs, clevel = c_i, var = "INR", PI_CUT = 0, var_order = 2))
    pi_pos <- ggplot_build(mr_plot_fig910(VAR = VAR1, nboot = runs, clevel = c_i, var = "INR", PI_CUT = 1, var_order = 1))
    dataset <- mr_aer_neg %>%
      dplyr::select(c('APITR','ACITR', 'GOV','RGDP','DEBT', 'INR','IR','CITB'))
    VAR1 <- list(dataset = as.matrix(dataset), 
                 lags = 4, 
                 iphor = 20, 
                 proxies = as.matrix(mr_aer_neg %>%
                                       dplyr::select(c(m_PI, m_CI)))
    )
    ci_neg <- ggplot_build(mr_plot_fig910(VAR = VAR1, nboot = runs, clevel = c_i, var = "INR", PI_CUT = 0, var_order = 1))
    pi_neg <- ggplot_build(mr_plot_fig910(VAR = VAR1, nboot = runs, clevel = c_i, var = "INR", PI_CUT = 1, var_order = 1))
    inr_p <- list(pi_neg, pi_pos)
    inr_c <- list(ci_neg, pi_pos)
    if(pi_cut == 1){
      inr_p[[2]]$data[[1]]$y <- -1*inr_p[[2]]$data[[1]]$y
      inr_p[[2]]$data[[2]]$y <- -1*inr_p[[2]]$data[[2]]$y
      inr_p[[2]]$data[[3]]$y <- -1*inr_p[[2]]$data[[3]]$y
      plot_i5(ggplot_list = inr_p, "PI Shock to Investment", var1 = "Negative Shock", var2 = "Positive Shock", num_vars = 2)
    } else if(pi_cut == 0){
      inr_c[[2]]$data[[1]]$y <- -1*as.numeric(inr_c[[2]]$data[[1]]$y)
      inr_c[[2]]$data[[2]]$y <- -1*as.numeric(inr_c[[2]]$data[[2]]$y)
      inr_c[[2]]$data[[3]]$y <- -1*as.numeric(inr_c[[2]]$data[[3]]$y)
      plot_i5(ggplot_list = inr_c, "CI Shock to Investment", var1 = "Negative Shock", var2 = "Positive Shock", num_vars = 2)
    }
  }
}

## Function for plotting different types of investment together by type. 
plot_type <- function(figure, pi_cut, runs, c_i){
  if(figure == "all"){
    if(pi_cut == 1){
      romer_extend_vars <- colnames(mr_aer %>% dplyr::select(contains("T50303") & !contains("RQ")))
      all_list <- list()
      df <- as.data.frame(matrix(ncol = length(romer_extend_vars) + 1, nrow = 20, dimnames=list(NULL, c(all_of(romer_extend_vars), "Quarters"))))
      df[,ncol(df)] <- seq(from = 1, to = 20)
      plot <- ggplot(data = df, aes(x = Quarters))
      for(i in 1:length(romer_extend_vars)){
        dataset <- mr_aer %>% dplyr::select(c('APITR','ACITR', 'GOV','RGDP','DEBT', romer_extend_vars[i],'CITB', 'm_PI', 'm_CI')) %>% tidyr::drop_na()
        VAR1 <- list(dataset = as.matrix(dataset %>% dplyr::select(-c('m_CI', 'm_PI'))), 
                     lags = 4, 
                     iphor = 20, 
                     proxies = as.matrix(dataset %>% dplyr::select(c(m_PI, m_CI))))
        all_list[[i]] <- ggplot_build(mr_plot_fig910(VAR = VAR1, nboot = 1, clevel = c_i, var = romer_extend_vars[i], PI_CUT = 1, var_order = 1))
        df[,i] <- all_list[[i]]$data[[1]]$y
      }
      df.m <- melt(df, id.vars = "Quarters")
      ggplot(data = df.m) + geom_line(aes(x = Quarters, y = value, color = variable), size = 1.05) + 
        geom_hline(aes(yintercept = 0), size = 1.1) + theme_minimal() + theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
        theme(panel.border = element_blank(), axis.line = element_line(), legend.position = "none") + xlab("Quarters Ahead") + ylab("Percent")
    } else if(pi_cut == 0){
      romer_extend_vars <- colnames(mr_aer %>% dplyr::select(contains("T50303") & !contains("RQ")))
      all_list <- list()
      df <- as.data.frame(matrix(ncol = length(romer_extend_vars) + 1, nrow = 20, dimnames=list(NULL, c(all_of(romer_extend_vars), "Quarters"))))
      df[,ncol(df)] <- seq(from = 1, to = 20)
      plot <- ggplot(data = df, aes(x = Quarters))
      for(i in 1:length(romer_extend_vars)){
        dataset <- mr_aer %>% dplyr::select(c('APITR','ACITR', 'GOV','RGDP','DEBT', romer_extend_vars[i],'CITB', 'm_PI', 'm_CI')) %>% tidyr::drop_na()
        VAR1 <- list(dataset = as.matrix(dataset %>% dplyr::select(-c('m_CI', 'm_PI'))), 
                     lags = 4, 
                     iphor = 20, 
                     proxies = as.matrix(dataset %>% dplyr::select(c(m_PI, m_CI))))
        all_list[[i]] <- ggplot_build(mr_plot_fig910(VAR = VAR1, nboot = 1, clevel = c(68), var = romer_extend_vars[i], PI_CUT = 0, var_order = 2))
        df[,i] <- all_list[[i]]$data[[1]]$y
      }
      df.m <- melt(df, id.vars = "Quarters")
      ggplot(data = df.m) + geom_line(aes(x = Quarters, y = value, color = variable), size = 1.05) + 
        geom_hline(aes(yintercept = 0), size = 1.1) + theme_minimal() + theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
        theme(panel.border = element_blank(), axis.line = element_line(), legend.position = "none") + xlab("Quarters Ahead") + ylab("Percent")
    }
  } else if(figure == "major_type"){
    dataset <- mr_aer %>%
      dplyr::select(c('APITR','ACITR', 'GOV','RGDP','DEBT', 'INR','IR','CITB'))
    VAR1 <- list(dataset = as.matrix(dataset), 
                 lags = 4, 
                 iphor = 20, 
                 proxies = as.matrix(mr_aer %>%
                                       dplyr::select(c(m_PI, m_CI)))
    )
    ci_1 <- ggplot_build(mr_plot_fig910(VAR = VAR1, nboot= runs, clevel = c_i, var = "INR", PI_CUT = 0, var_order = 1))
    ci_2 <- ggplot_build(mr_plot_fig910(VAR = VAR1, nboot= runs, clevel = c_i, var = "IR", PI_CUT = 0, var_order = 1))
    pi_1 <- ggplot_build(mr_plot_fig910(VAR = VAR1, nboot= runs, clevel = c_i, var = "INR", PI_CUT = 1, var_order = 2))
    pi_2 <- ggplot_build(mr_plot_fig910(VAR = VAR1, nboot= runs, clevel = c_i, var = "IR", PI_CUT = 1, var_order = 2))
    if(pi_cut == 1){
      pi_list <- list(pi_1, pi_2)
      plot_i5(pi_list, "By Major Type", var1 = "Nonresidential", var2 = "Residential", num_vars = 2)
    } else{
      ci_list <- list(ci_1, ci_2)
      plot_i5(ci_list, "By Major Type", var1 = "Nonresidential", var2 = "Residential", num_vars = 2)
    }
  } else if(figure == "nonresidential"){
    dataset <- mr_aer %>%
      dplyr::select(c('APITR','ACITR', 'GOV','RGDP','DEBT',"T50303_3_Q", 'CITB'))
    VAR1 <- list(dataset = as.matrix(dataset), 
                 lags = 4, 
                 iphor = 20, 
                 proxies = as.matrix(mr_aer %>%
                                       dplyr::select(c(m_PI, m_CI)))
    )
    pi_1 <- ggplot_build(mr_plot_fig910(VAR = VAR1, nboot= runs, clevel = c_i, var = "T50303_3_Q", PI_CUT = 1, var_order = 1))
    ci_1 <- ggplot_build(mr_plot_fig910(VAR = VAR1, nboot= runs, clevel = c_i, var = "T50303_3_Q", PI_CUT = 0, var_order = 2))
    dataset <- mr_aer %>%
      dplyr::select(c('APITR','ACITR', 'GOV','RGDP','DEBT',"T50303_9_Q", 'CITB'))
    VAR1 <- list(dataset = as.matrix(dataset), 
                 lags = 4, 
                 iphor = 20, 
                 proxies = as.matrix(mr_aer %>%
                                       dplyr::select(c(m_PI, m_CI)))
    )
    pi_2 <- ggplot_build(mr_plot_fig910(VAR = VAR1, nboot= runs, clevel = c_i, var = "T50303_9_Q", PI_CUT = 1, var_order = 1))
    ci_2 <- ggplot_build(mr_plot_fig910(VAR = VAR1, nboot= runs, clevel = c_i, var = "T50303_9_Q", PI_CUT = 0, var_order = 2))
    dataset <- mr_aer %>%
      dplyr::select(c('APITR','ACITR', 'GOV','RGDP','DEBT',"T50303_16_Q", 'CITB'))
    VAR1 <- list(dataset = as.matrix(dataset), 
                 lags = 4, 
                 iphor = 20, 
                 proxies = as.matrix(mr_aer %>%
                                       dplyr::select(c(m_PI, m_CI)))
    )
    pi_3 <- ggplot_build(mr_plot_fig910(VAR = VAR1, nboot= runs, clevel = c_i, var = "T50303_16_Q", PI_CUT =  1, var_order = 1))
    ci_3 <- ggplot_build(mr_plot_fig910(VAR = VAR1, nboot= runs, clevel = c_i, var = "T50303_16_Q", PI_CUT =  0, var_order = 2))
    
    if(pi_cut == 0){
      ci_list <- list(ci_1, ci_2, ci_3)
      plot_i5(ci_list, "By Nonresidential Type", "Structures", "Equipment", "Intellectual Property", num_vars = 3)
    } else{
      pi_list <- list(pi_1, pi_2, pi_3)
      plot_i5(pi_list, "By Nonresidential Type", "Structures", "Equipment", "Intellectual Property", num_vars = 3) 
    }
  } else if(figure == "equipment"){
    dataset <- mr_aer  %>%
      dplyr::select(c('APITR','ACITR', 'GOV','RGDP','DEBT',"T50303_10_Q", 'CITB'))
    VAR1 <- list(dataset = as.matrix(dataset), 
                 lags = 4, 
                 iphor = 20, 
                 proxies = as.matrix(mr_aer %>% 
                                       dplyr::select(c(m_PI, m_CI)))
    )
    pi_1 <- ggplot_build(mr_plot_fig910(VAR = VAR1, nboot= runs, clevel = c_i, var = "T50303_10_Q", PI_CUT = 1, var_order = 1))
    ci_1 <- ggplot_build(mr_plot_fig910(VAR = VAR1, nboot= runs, clevel = c_i, var = "T50303_10_Q", PI_CUT = 0, var_order = 2))
    dataset <- mr_aer %>% 
      dplyr::select(c('APITR','ACITR', 'GOV','RGDP','DEBT',"T50303_13_Q", 'CITB'))
    VAR1 <- list(dataset = as.matrix(dataset), 
                 lags = 4, 
                 iphor = 20, 
                 proxies = as.matrix(mr_aer %>%
                                       dplyr::select(c(m_PI, m_CI)))
    )
    pi_2 <- ggplot_build(mr_plot_fig910(VAR = VAR1, nboot= runs, clevel = c_i, var = "T50303_13_Q", PI_CUT = 1, var_order = 1))
    ci_2 <- ggplot_build(mr_plot_fig910(VAR = VAR1, nboot= runs, clevel = c_i, var = "T50303_13_Q", PI_CUT = 0, var_order = 2))
    dataset <- mr_aer %>% 
      dplyr::select(c('APITR','ACITR', 'GOV','RGDP','DEBT',"T50303_14_Q", 'CITB'))
    VAR1 <- list(dataset = as.matrix(dataset), 
                 lags = 4, 
                 iphor = 20, 
                 proxies = as.matrix(mr_aer %>% 
                                       dplyr::select(c(m_PI, m_CI)))
    )
    pi_3 <- ggplot_build(mr_plot_fig910(VAR = VAR1, nboot= runs, clevel = c_i, var = "T50303_14_Q", PI_CUT =  1, var_order = 1))
    ci_3 <- ggplot_build(mr_plot_fig910(VAR = VAR1, nboot= runs, clevel = c_i, var = "T50303_14_Q", PI_CUT =  0, var_order = 2))
    
    dataset <- mr_aer %>%
      dplyr::select(c('APITR','ACITR', 'GOV','RGDP','DEBT',"T50303_15_Q", 'CITB'))
    VAR1 <- list(dataset = as.matrix(dataset), 
                 lags = 4, 
                 iphor = 20, 
                 proxies = as.matrix(mr_aer %>%
                                       dplyr::select(c(m_PI, m_CI)))
    )
    pi_4 <- ggplot_build(mr_plot_fig910(VAR = VAR1, nboot= runs, clevel = c_i, var = "T50303_15_Q", PI_CUT = 1, var_order = 1))
    ci_4 <- ggplot_build(mr_plot_fig910(VAR = VAR1, nboot= runs, clevel = c_i, var = "T50303_15_Q", PI_CUT = 0, var_order = 2))
    if(pi_cut == 1){
      pi_list <- list(pi_1, pi_2, pi_3, pi_4)
      plot_i5(pi_list, "By Equipment Type", "Information Processing", "Industrial", "Transportation", "Other", num_vars = 4)
    } else if(pi_cut == 0){
      ci_list <- list(ci_1, ci_2, ci_3, ci_4)
      plot_i5(ci_list, var = "By Equipment Type", var1 = "Information Processing", var2 = "Industrial", var3 = "Transportation", var4 = "Other", num_vars = 4)
    }
  } else if(figure == "structures"){
    dataset <- mr_aer %>% filter(Date >= 1958) %>%
      dplyr::select(c('APITR','ACITR', 'GOV','RGDP','DEBT',"T50303_4_Q", 'CITB'))
    VAR1 <- list(dataset = as.matrix(dataset), 
                 lags = 4, 
                 iphor = 20, 
                 proxies = as.matrix(mr_aer %>% filter(Date >= 1958) %>%
                                       dplyr::select(c(m_PI, m_CI)))
    )
    pi_1 <- ggplot_build(mr_plot_fig910(VAR = VAR1, nboot= runs, clevel = c_i, var = "T50303_4_Q", PI_CUT = 1, var_order = 1))
    ci_1 <- ggplot_build(mr_plot_fig910(VAR = VAR1, nboot= runs, clevel = c_i, var = "T50303_4_Q", PI_CUT = 0, var_order = 2))
    dataset <- mr_aer %>% filter(Date >= 1958) %>%
      dplyr::select(c('APITR','ACITR', 'GOV','RGDP','DEBT',"T50303_5_Q", 'CITB'))
    VAR1 <- list(dataset = as.matrix(dataset), 
                 lags = 4, 
                 iphor = 20, 
                 proxies = as.matrix(mr_aer %>% filter(Date >= 1958) %>%
                                       dplyr::select(c(m_PI, m_CI)))
    )
    pi_2 <- ggplot_build(mr_plot_fig910(VAR = VAR1, nboot= runs, clevel = c_i, var = "T50303_5_Q", PI_CUT = 1, var_order = 1))
    ci_2 <- ggplot_build(mr_plot_fig910(VAR = VAR1, nboot= runs, clevel = c_i, var = "T50303_5_Q", PI_CUT = 0, var_order = 2))
    dataset <- mr_aer %>% filter(Date >= 1958) %>%
      dplyr::select(c('APITR','ACITR', 'GOV','RGDP','DEBT',"T50303_6_Q", 'CITB'))
    VAR1 <- list(dataset = as.matrix(dataset), 
                 lags = 4, 
                 iphor = 20, 
                 proxies = as.matrix(mr_aer %>% filter(Date >= 1958) %>%
                                       dplyr::select(c(m_PI, m_CI)))
    )
    pi_3 <- ggplot_build(mr_plot_fig910(VAR = VAR1, nboot= runs, clevel = c_i, var = "T50303_6_Q", PI_CUT =  1, var_order = 1))
    ci_3 <- ggplot_build(mr_plot_fig910(VAR = VAR1, nboot= runs, clevel = c_i, var = "T50303_6_Q", PI_CUT =  0, var_order = 2))
    
    dataset <- mr_aer %>% filter(Date >= 1958) %>%
      dplyr::select(c('APITR','ACITR', 'GOV','RGDP','DEBT',"T50303_7_Q", 'CITB'))
    VAR1 <- list(dataset = as.matrix(dataset), 
                 lags = 4, 
                 iphor = 20, 
                 proxies = as.matrix(mr_aer %>% filter(Date >= 1958) %>%
                                       dplyr::select(c(m_PI, m_CI)))
    )
    pi_4 <- ggplot_build(mr_plot_fig910(VAR = VAR1, nboot= runs, clevel = c_i, var = "T50303_7_Q", PI_CUT = 1, var_order = 1))
    ci_4 <- ggplot_build(mr_plot_fig910(VAR = VAR1, nboot= runs, clevel = c_i, var = "T50303_7_Q", PI_CUT = 0, var_order = 2))
    dataset <- mr_aer %>% filter(Date >= 1958) %>%
      dplyr::select(c('APITR','ACITR', 'GOV','RGDP','DEBT',"T50303_8_Q", 'CITB'))
    VAR1 <- list(dataset = as.matrix(dataset), 
                 lags = 4, 
                 iphor = 20, 
                 proxies = as.matrix(mr_aer %>% filter(Date >= 1958) %>%
                                       dplyr::select(c(m_PI, m_CI)))
    )
    pi_5 <- ggplot_build(mr_plot_fig910(VAR = VAR1, nboot= runs, clevel =c_i, var = "T50303_8_Q", PI_CUT = 1, var_order = 1))
    ci_5 <- ggplot_build(mr_plot_fig910(VAR = VAR1, nboot= runs, clevel = c_i, var = "T50303_8_Q", PI_CUT = 0, var_order = 2))
    if(pi_cut == 1){
      pi_list <- list(pi_1, pi_2, pi_3, pi_4, pi_5)
      plot_i5(pi_list, "By Structures Type", "Commercial", "Manufacturing", "Power", "Mining", "Other", num_vars = 5)
    } else{
      ci_list <- list(ci_1, ci_2, ci_3, ci_4, ci_5)
      plot_i5(ci_list, "By Structures Type", "Commercial", "Manufacturing", "Power", "Mining", "Other", num_vars = 5)
    }
  } else if(figure == "ip_type"){
    dataset <- mr_aer %>% filter(Date >= 1959) %>%
      dplyr::select(c('APITR','ACITR', 'GOV','RGDP','DEBT',"T50303_17_Q", 'CITB'))
    VAR1 <- list(dataset = as.matrix(dataset), 
                 lags = 4, 
                 iphor = 20, 
                 proxies = as.matrix(mr_aer %>% filter(Date >= 1959) %>%
                                       dplyr::select(c(m_PI, m_CI)))
    )
    pi_1 <- ggplot_build(mr_plot_fig910(VAR = VAR1, nboot= runs, clevel = c_i, var = "T50303_17_Q", PI_CUT = 1, var_order = 1))
    ci_1 <- ggplot_build(mr_plot_fig910(VAR = VAR1, nboot= runs, clevel = c_i, var = "T50303_17_Q", PI_CUT = 0, var_order = 2))
    dataset <- mr_aer %>%
      dplyr::select(c('APITR','ACITR', 'GOV','RGDP','DEBT',"T50303_18_Q", 'CITB'))
    VAR1 <- list(dataset = as.matrix(dataset), 
                 lags = 4, 
                 iphor = 20, 
                 proxies = as.matrix(mr_aer %>%
                                       dplyr::select(c(m_PI, m_CI)))
    )
    pi_2 <- ggplot_build(mr_plot_fig910(VAR = VAR1, nboot= runs, clevel = c_i, var = "T50303_18_Q", PI_CUT = 1, var_order = 1))
    ci_2 <- ggplot_build(mr_plot_fig910(VAR = VAR1, nboot= runs, clevel = c_i, var = "T50303_18_Q", PI_CUT = 0, var_order = 2))
    dataset <- mr_aer %>%
      dplyr::select(c('APITR','ACITR', 'GOV','RGDP','DEBT',"T50303_19_Q", 'CITB'))
    VAR1 <- list(dataset = as.matrix(dataset), 
                 lags = 4, 
                 iphor = 20, 
                 proxies = as.matrix(mr_aer %>%
                                       dplyr::select(c(m_PI, m_CI)))
    )
    pi_3 <- ggplot_build(mr_plot_fig910(VAR = VAR1, nboot= runs, clevel = c_i, var = "T50303_19_Q", PI_CUT =  1, var_order = 1))
    ci_3 <- ggplot_build(mr_plot_fig910(VAR = VAR1, nboot= runs, clevel = c_i, var = "T50303_19_Q", PI_CUT =  0, var_order = 2))
    if(pi_cut == 1){
      pi_list <- list(pi_1, pi_2, pi_3)
      plot_i5(pi_list, "By Intellectual Property Type", "Software", "R&D", "Entertainment", num_vars = 3)
    } else{
      ci_list <- list(ci_1, ci_2, ci_3)
      plot_i5(ci_list, "By Intellectual Property Type", "Software", "R&D", "Entertainment", num_vars = 3)
    }
  }
}
