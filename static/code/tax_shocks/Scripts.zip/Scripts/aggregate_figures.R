### Generate VARS using Romer-Romer specification
data_dir <- "C:/Users/j.mejia/Downloads/macro_invt_elasticities/"
source(file.path(data_dir, "macro_invt_elasticities/Scripts/FUNCTIONS.R"))

romerdata_q <- fread(file.path(data_dir,"macro_invt_elasticities/Data/romerdata_q_prepped.csv"))
nipa_a <- fread(file.path(data_dir,"macro_invt_elasticities/Data/nipa_fa_vals.csv"))
mr_aer <- fread(file.path(data_dir,"macro_invt_elasticities/Data/mr_aer_prepped.csv"))

#To recreate results for Figure ### (impulse responses from NIPA 1.1.3 10-12 from exogenrratio). 
fig1rr("structures")
fig1rr("equipment")
fig1rr("ip")

# Figure 2
fig2()


##Heterogeneity by type of investment
hetero_rr("all")
hetero_rr("major_type")
hetero_rr("nonresidential")
hetero_rr("structures")
hetero_rr("equipment")
hetero_rr("ip")

# IRFs by legal type GFCF
hetero_rr("gfcf_ci")
hetero_rr("gfcf_pi")

## IRFs by Legal type, FOF
hetero_rr("fof_tot_ci")
hetero_rr("fof_tot_pi")
hetero_rr("fof_struct_ci")
hetero_rr("fof_struct_pi")
hetero_rr("fof_equip_ci")
hetero_rr("fof_equip_pi")
hetero_rr("fof_intan_ci")
hetero_rr("fof_intan_pi")


##IRFs by legal type, fixed assets
hetero_rr("faat_tot_ci")
hetero_rr("faat_tot_pi")
hetero_rr("faat_equip_ci")
hetero_rr("faat_equip_pi")
hetero_rr("faat_struct_ci")
hetero_rr("faat_struct_pi")
hetero_rr("faat_intan_ci")
hetero_rr("faat_intan_pi")

## Split-Sample
split_rr(variable = "GDP", title = "GDP", split = 1976)
split_rr(variable = "GPDI", title = "GPDI", split = 1976)
split_rr(variable = "FI", title = "FI", split = 1976)
split_rr(variable = "RES", title = "Residential Investment", split = 1976)
split_rr(variable = "NONRES", title = "Nonresidential Investment", split = 1976)

# Split Sample, Split Shock
hetero_rr("gdp_split")
hetero_rr("gpdi_split")
hetero_rr("fi_split")
hetero_rr("nonres_split")
hetero_rr("res_split")

##PROXY SVAR PARAMETERS
runs <- 1000
c_i <- 90

## ALL
# PI Shock
plot_type(figure = "all", pi_cut = 1, runs, c_i)
#CI Shock
plot_type(figure = "all", pi_cut = 0, runs, c_i)

## By Major Type
#PI Shock
plot_type(figure = "major_type", pi_cut = 1, runs, c_i)
#CI Shock
plot_type(figure = "major_type", pi_cut = 0, runs, c_i)

## Nonresidential Type
#PI Shock
plot_type(figure = "nonresidential", pi_cut = 1, runs, c_i)
#CI Shock
plot_type(figure = "nonresidential", pi_cut = 0, runs, c_i)

## By Structures Type
# PI Shock
plot_type(figure = "structures", pi_cut = 1, runs, c_i)
#CI Shock
plot_type(figure = "structures", pi_cut = 0, runs, c_i)

## By Equipment Type
#PI Shock
plot_type(figure = "equipment", pi_cut = 1, runs, c_i)
#CI Shock
plot_type(figure = "equipment", pi_cut = 0, runs, c_i)

## By Intellectual Property Type
## PI Shock
plot_type(figure = "ip_type", pi_cut = 1, runs, c_i)
## CI Shock
plot_type(figure = "ip_type", pi_cut = 0, runs, c_i)


## Rep Fig 1
plot_ind_mr(variable = "structures", runs, c_i)
plot_ind_mr(variable = "equipment", runs, c_i)
plot_ind_mr(variable = "ip", runs, c_i)

## Fig 3
## 1976 Split
## PI Shock (GDP)
plot_time_split("gdp", pi_cut = 1, runs, c_i)
## CI Shock (GDP)
plot_time_split("gdp", pi_cut = 0, runs, c_i)
## PI Shock (Investment)
plot_time_split("investment", pi_cut = 1, runs, c_i)
## CI Shock (Investment)
plot_time_split("investment", pi_cut = 0, runs, c_i)


## Fig 4 - Split Shocks 1975Q1-2006Q4
# PI Shock to Output
plot_pos_neg_split(type = "gdp", pi_cut = 1, runs, c_i)
# CI Shock to Output
plot_pos_neg_split(type = "gdp", pi_cut = 0, runs, c_i)
# PI Shock to Nonresidential Investment
plot_pos_neg_split(type = "investment", pi_cut = 1, runs, c_i)
# CI Shock to Nonresidential Investment
plot_pos_neg_split(type = "investment", pi_cut = 0, runs, c_i)

## Corporate INV
## Total Investment
two_svar_irf_inv("FAAt407_37_A_KQ", start_date = 1953, "Total Investment", runs, c_i)
## Equipment
two_svar_irf_inv("FAAt407_38_A_KQ", start_date = 1953, "Equipment", runs = 1000, c_i = 68)
## Structures
two_svar_irf_inv("FAAt407_39_A_KQ", start_date = 1953, "Structures", runs = 1000, c_i = 68)
## Physical
two_svar_irf_inv("FAAt407_3839_A_KQ", start_date = 1953, "Physical Investment", runs, c_i)
## R&D
two_svar_irf_inv("FAAt407_40_A_KQ", start_date = 1953, "Intellectual Property", runs, c_i)

## Noncorporate
## Total Investment
two_svar_irf_inv("FAAt407_41_A_KQ", start_date = 1960, "Total Investment", runs, c_i)
## Equipment
two_svar_irf_inv("FAAt407_42_A_KQ", start_date = 1960, "Equipment", runs = 1000, c_i = 68)
## Structures
two_svar_irf_inv("FAAt407_43_A_KQ", start_date = 1960, "Structures", runs = 1000, c_i = 68)
## Physical
two_svar_irf_inv("FAAt407_4243_A_KQ", start_date = 1960, "Physical Investment", runs, c_i)
## R&D
two_svar_irf_inv("FAAt407_44_A_KQ", start_date = 1960, "Intellectual Property", runs, c_i)
