## Panel Regressions. This script runs different specifications of panel regressions. 

data_dir <- 'C:/Users/Jackson_Mejia/Documents/ERM_Practice/'

source(file.path(data_dir, "macro_invt_elasticities/Scripts/FUNCTIONS.R"))

### Quarterly CI

compustat <- fread(file.path(data_dir,"macro_invt_elasticities/Data/compustat_quarterly_prepped.csv"))

## Baseline Specification
coeftest(plm(g_invt_phy_adj_log ~ dplyr::lag(T_CI, n = 1L) + as.factor(fqtr) ,
            model = c("within"), index = c("cont_id"), data = compustat), vcov. = vcovHC, type = "HC1", method = "white1", cluster = "group")

coeftest(plm(g_invt_phy_adj_log ~ dplyr::lag(T_CI, n = 1L)*mnc + as.factor(fqtr), 
            model = c("within"), index = c("cont_id"), data = compustat), vcov. = vcovHC, type = "HC1", method = "white1", cluster = "group")

coeftest(plm(g_invt_phy_adj_log ~   dplyr::lag(T_CI, n = 1L)*high_roa  + as.factor(fqtr), 
            model = c("within"), index = c("cont_id"), data = compustat), vcov. = vcovHC, type = "HC1", method = "white1", cluster = "group")

coeftest(plm(g_invt_phy_adj_log ~  dplyr::lag(T_CI, n = 1L)*hp_con  + as.factor(fqtr), 
            model = c("within"), index = c("cont_id"), data = compustat), vcov. = vcovHC, type = "HC1", method = "white1", cluster = "group")

coeftest(plm(g_invt_phy_adj_log ~   dplyr::lag(T_CI, n = 1L)*kz_con+ as.factor(fqtr), 
            model = c("within"), index = c("cont_id"), data = compustat), vcov. = vcovHC, type = "HC1", method = "white1", cluster = "group")

coeftest(plm(g_invt_phy_adj_log ~   dplyr::lag(T_CI, n = 1L)*big_firm + as.factor(fqtr), 
            model = c("within"), index = c("cont_id"), data = compustat), vcov. = vcovHC, type = "HC1", method = "white1", cluster = "group")

coeftest(plm(g_invt_phy_adj_log ~   dplyr::lag(T_CI, n = 1L)*div_payer + as.factor(fqtr), 
            model = c("within"), index = c("cont_id"), data = compustat), vcov. = vcovHC, type = "HC1", method = "white1", cluster = "group")

coeftest(plm(g_invt_phy_adj_log ~   dplyr::lag(T_CI, n = 1L)*as.factor(NAICS) + as.factor(fqtr), 
            model = c("within"), index = c("cont_id"), data = compustat), vcov. = vcovHC, type = "HC1", method = "white1", cluster = "group")

coeftest(plm(g_invt_phy_adj_log ~   dplyr::lag(T_CI, n = 1L)*highleverage + as.factor(fqtr), 
            model = c("within"), index = c("cont_id"), data = compustat), vcov. = vcovHC, type = "HC1", method = "white1", cluster = "group")

coeftest(plm(g_invt_phy_adj_log ~   dplyr::lag(T_CI, n = 1L)*high_intan + as.factor(fqtr), 
            model = c("within"), index = c("cont_id"), data = compustat), vcov. = vcovHC, type = "HC1", method = "white1", cluster = "group")

coeftest(plm(g_invt_phy_adj_log ~   dplyr::lag(T_CI, n = 1L)*high_know + as.factor(fqtr), 
            model = c("within"), index = c("cont_id"), data = compustat), vcov. = vcovHC, type = "HC1", method = "white1", cluster = "group")

coeftest(plm(g_invt_phy_adj_log ~  dplyr::lag(T_CI, n = 1L)*high_org + as.factor(fqtr), 
            model = c("within"), index = c("cont_id"), data = compustat), vcov. = vcovHC, type = "HC1", method = "white1", cluster = "group")

coeftest(plm(g_invt_phy_adj_log ~ dplyr::lag(T_CI, n = 1L)*young_firm + as.factor(fqtr) ,
             model = c("within"), index = c("cont_id"), data = compustat), vcov. = vcovHC, type = "HC1", method = "white1", cluster = "group")





## Positive

coeftest(plm(g_invt_phy_adj_log ~ dplyr::lag(T_CI_POS, n = 1L) + as.factor(fqtr) ,
             model = c("within"), index = c("cont_id"), data = compustat), vcov. = vcovHC, type = "HC1", method = "white1", cluster = "group")

coeftest(plm(g_invt_phy_adj_log ~ dplyr::lag(T_CI_POS, n = 1L)*mnc + as.factor(fqtr), 
             model = c("within"), index = c("cont_id"), data = compustat), vcov. = vcovHC, type = "HC1", method = "white1", cluster = "group")

coeftest(plm(g_invt_phy_adj_log ~   dplyr::lag(T_CI_POS, n = 1L)*high_roa  + as.factor(fqtr), 
             model = c("within"), index = c("cont_id"), data = compustat), vcov. = vcovHC, type = "HC1", method = "white1", cluster = "group")

coeftest(plm(g_invt_phy_adj_log ~  dplyr::lag(T_CI_POS, n = 1L)*hp_con  + as.factor(fqtr), 
             model = c("within"), index = c("cont_id"), data = compustat), vcov. = vcovHC, type = "HC1", method = "white1", cluster = "group")

coeftest(plm(g_invt_phy_adj_log ~   dplyr::lag(T_CI_POS, n = 1L)*kz_con+ as.factor(fqtr), 
             model = c("within"), index = c("cont_id"), data = compustat), vcov. = vcovHC, type = "HC1", method = "white1", cluster = "group")

coeftest(plm(g_invt_phy_adj_log ~   dplyr::lag(T_CI_POS, n = 1L)*big_firm + as.factor(fqtr), 
             model = c("within"), index = c("cont_id"), data = compustat), vcov. = vcovHC, type = "HC1", method = "white1", cluster = "group")

coeftest(plm(g_invt_phy_adj_log ~   dplyr::lag(T_CI_POS, n = 1L)*div_payer + as.factor(fqtr), 
             model = c("within"), index = c("cont_id"), data = compustat), vcov. = vcovHC, type = "HC1", method = "white1", cluster = "group")

coeftest(plm(g_invt_phy_adj_log ~   dplyr::lag(T_CI_POS, n = 1L)*as.factor(NAICS) + as.factor(fqtr), 
             model = c("within"), index = c("cont_id"), data = compustat), vcov. = vcovHC, type = "HC1", method = "white1", cluster = "group")

coeftest(plm(g_invt_phy_adj_log ~   dplyr::lag(T_CI_POS, n = 1L)*highleverage + as.factor(fqtr), 
             model = c("within"), index = c("cont_id"), data = compustat), vcov. = vcovHC, type = "HC1", method = "white1", cluster = "group")

coeftest(plm(g_invt_phy_adj_log ~   dplyr::lag(T_CI_POS, n = 1L)*high_intan + as.factor(fqtr), 
             model = c("within"), index = c("cont_id"), data = compustat), vcov. = vcovHC, type = "HC1", method = "white1", cluster = "group")

coeftest(plm(g_invt_phy_adj_log ~   dplyr::lag(T_CI_POS, n = 1L)*high_know + as.factor(fqtr), 
             model = c("within"), index = c("cont_id"), data = compustat), vcov. = vcovHC, type = "HC1", method = "white1", cluster = "group")

coeftest(plm(g_invt_phy_adj_log ~  dplyr::lag(T_CI_POS, n = 1L)*high_org + as.factor(fqtr), 
             model = c("within"), index = c("cont_id"), data = compustat), vcov. = vcovHC, type = "HC1", method = "white1", cluster = "group")

coeftest(plm(g_invt_phy_adj_log ~ dplyr::lag(T_CI_POS, n = 1L)*young_firm + as.factor(fqtr) ,
             model = c("within"), index = c("cont_id"), data = compustat), vcov. = vcovHC, type = "HC1", method = "white1", cluster = "group")

## Neg

coeftest(plm(g_invt_phy_adj_log ~ dplyr::lag(T_CI_NEG, n = 1L) + as.factor(fqtr) ,
             model = c("within"), index = c("cont_id"), data = compustat), vcov. = vcovHC, type = "HC1", method = "white1", cluster = "group")

coeftest(plm(g_invt_phy_adj_log ~ dplyr::lag(T_CI_NEG, n = 1L)*mnc + as.factor(fqtr), 
             model = c("within"), index = c("cont_id"), data = compustat), vcov. = vcovHC, type = "HC1", method = "white1", cluster = "group")

coeftest(plm(g_invt_phy_adj_log ~   dplyr::lag(T_CI_NEG, n = 1L)*high_roa  + as.factor(fqtr), 
             model = c("within"), index = c("cont_id"), data = compustat), vcov. = vcovHC, type = "HC1", method = "white1", cluster = "group")

coeftest(plm(g_invt_phy_adj_log ~  dplyr::lag(T_CI_NEG, n = 1L)*hp_con  + as.factor(fqtr), 
             model = c("within"), index = c("cont_id"), data = compustat), vcov. = vcovHC, type = "HC1", method = "white1", cluster = "group")

coeftest(plm(g_invt_phy_adj_log ~   dplyr::lag(T_CI_NEG, n = 1L)*kz_con+ as.factor(fqtr), 
             model = c("within"), index = c("cont_id"), data = compustat), vcov. = vcovHC, type = "HC1", method = "white1", cluster = "group")

coeftest(plm(g_invt_phy_adj_log ~   dplyr::lag(T_CI_NEG, n = 1L)*big_firm + as.factor(fqtr), 
             model = c("within"), index = c("cont_id"), data = compustat), vcov. = vcovHC, type = "HC1", method = "white1", cluster = "group")
##POTENTIAL HERE
coeftest(plm(g_invt_phy_adj_log ~   dplyr::lag(T_CI_NEG, n = 1L)*div_payer + as.factor(fqtr), 
             model = c("within"), index = c("cont_id"), data = compustat), vcov. = vcovHC, type = "HC1", method = "white1", cluster = "group")

coeftest(plm(g_invt_phy_adj_log ~   dplyr::lag(T_CI_NEG, n = 1L)*as.factor(NAICS) + as.factor(fqtr), 
             model = c("within"), index = c("cont_id"), data = compustat), vcov. = vcovHC, type = "HC1", method = "white1", cluster = "group")

coeftest(plm(g_invt_phy_adj_log ~   dplyr::lag(T_CI_NEG, n = 1L)*highleverage + as.factor(fqtr), 
             model = c("within"), index = c("cont_id"), data = compustat), vcov. = vcovHC, type = "HC1", method = "white1", cluster = "group")

coeftest(plm(g_invt_phy_adj_log ~   dplyr::lag(T_CI_NEG, n = 1L)*high_intan + as.factor(fqtr), 
             model = c("within"), index = c("cont_id"), data = compustat), vcov. = vcovHC, type = "HC1", method = "white1", cluster = "group")

coeftest(plm(g_invt_phy_adj_log ~   dplyr::lag(T_CI_NEG, n = 1L)*high_know + as.factor(fqtr), 
             model = c("within"), index = c("cont_id"), data = compustat), vcov. = vcovHC, type = "HC1", method = "white1", cluster = "group")

coeftest(plm(g_invt_phy_adj_log ~  dplyr::lag(T_CI_NEG, n = 1L)*high_org + as.factor(fqtr), 
             model = c("within"), index = c("cont_id"), data = compustat), vcov. = vcovHC, type = "HC1", method = "white1", cluster = "group")
##HERE
coeftest(plm(g_invt_phy_adj_log ~ dplyr::lag(T_CI_NEG, n = 1L)*young_firm + as.factor(fqtr) ,
             model = c("within"), index = c("cont_id"), data = compustat), vcov. = vcovHC, type = "HC1", method = "white1", cluster = "group")


## With Firm Controls

coeftest(plm(g_invt_phy_adj_log ~ dplyr::lag(T_CI, n = 1L) + dplyr::lag(g_invt_phy_adj_log, n = 1L)  + as.factor(fqtr) + dplyr::lag(liquidity, n = 1L) +
               dplyr::lag(log(atq_adj), n = 1L) + dplyr::lag(saleq_adj_log_growth, n = 1L) +
               dplyr::lag(log(ppentq_adj_interp), n = 1L) + dplyr::lag(leverage, n = 1L) + dplyr::lag(tobins_q_interp, n = 1L), 
             model = c("within"), index = c("cont_id"), data = compustat), vcov. = vcovHC, type = "HC1", method = "white1", cluster = "group")
coeftest(plm(g_invt_phy_adj_log ~ dplyr::lag(T_CI, n = 1L)*mnc + as.factor(fqtr)
             + dplyr::lag(g_invt_phy_adj_log, n = 1L) + dplyr::lag(liquidity, n = 1L) +
               dplyr::lag(log(atq_adj), n = 1L) + dplyr::lag(saleq_adj_log_growth, n = 1L) + dplyr::lag(tobins_q_interp, n = 1L) +
               dplyr::lag(log(ppentq_adj_interp), n = 1L) + dplyr::lag(leverage, n = 1L), 
             model = c("within"), index = c("cont_id"), data = compustat), vcov. = vcovHC, type = "HC1", method = "white1", cluster = "group")
coeftest(plm(g_invt_phy_adj_log ~   dplyr::lag(T_CI, n = 1L)*high_roa  + as.factor(fqtr)  + dplyr::lag(g_invt_phy_adj_log, n = 1L) + dplyr::lag(liquidity, n = 1L) +
               dplyr::lag(log(atq_adj), n = 1L) + dplyr::lag(saleq_adj_log_growth, n = 1L) +
               dplyr::lag(log(ppentq_adj_interp), n = 1L) + dplyr::lag(leverage, n = 1L)  +dplyr::lag(tobins_q_interp, n = 1L), 
             model = c("within"), index = c("cont_id"), data = compustat), vcov. = vcovHC, type = "HC1", method = "white1", cluster = "group")
coeftest(plm(g_invt_phy_adj_log ~  dplyr::lag(T_CI, n = 1L)*hp_con + as.factor(fqtr)+ 
               dplyr::lag(g_invt_phy_adj_log, n = 1L) + dplyr::lag(liquidity, n = 1L) +
               dplyr::lag(log(atq_adj), n = 1L) + dplyr::lag(saleq_adj_log_growth, n = 1L) +
               dplyr::lag(log(ppentq_adj_interp), n = 1L) + dplyr::lag(leverage, n = 1L) +dplyr::lag(tobins_q_interp, n = 1L), 
             model = c("within"), index = c("cont_id"), data = compustat), vcov. = vcovHC, type = "HC1", method = "white1", cluster = "group")
coeftest(plm(g_invt_phy_adj_log ~   dplyr::lag(T_CI, n = 1L)*kz_con + as.factor(fqtr) + 
               dplyr::lag(g_invt_phy_adj_log, n = 1L) + dplyr::lag(liquidity, n = 1L) +
               dplyr::lag(log(atq_adj), n = 1L) + dplyr::lag(saleq_adj_log_growth, n = 1L) +
               dplyr::lag(log(ppentq_adj_interp), n = 1L) + dplyr::lag(leverage, n = 1L) +dplyr::lag(tobins_q_interp, n = 1L), 
             model = c("within"), index = c("cont_id"), data = compustat), vcov. = vcovHC, type = "HC1", method = "white1", cluster = "group")
coeftest(plm(g_invt_phy_adj_log ~   dplyr::lag(T_CI, n = 1L)*big_firm + as.factor(fqtr) + 
               dplyr::lag(g_invt_phy_adj_log, n = 1L) + dplyr::lag(liquidity, n = 1L) +
               dplyr::lag(log(atq_adj), n = 1L) + dplyr::lag(saleq_adj_log_growth, n = 1L) +
               dplyr::lag(log(ppentq_adj_interp), n = 1L) + dplyr::lag(leverage, n = 1L) +dplyr::lag(tobins_q_interp, n = 1L), 
             model = c("within"), index = c("cont_id"), data = compustat), vcov. = vcovHC, type = "HC1", method = "white1", cluster = "group")
coeftest(plm(g_invt_phy_adj_log ~   dplyr::lag(T_CI, n = 1L)*div_payer + as.factor(fqtr) + 
               dplyr::lag(g_invt_phy_adj_log, n = 1L) + dplyr::lag(liquidity, n = 1L) +
               dplyr::lag(log(atq_adj), n = 1L) + dplyr::lag(saleq_adj_log_growth, n = 1L) +
               dplyr::lag(log(ppentq_adj_interp), n = 1L) + dplyr::lag(leverage, n = 1L) +dplyr::lag(tobins_q_interp, n = 1L), 
             model = c("within"), index = c("cont_id"), data = compustat), vcov. = vcovHC, type = "HC1", method = "white1", cluster = "group")
coeftest(plm(g_invt_phy_adj_log ~   dplyr::lag(T_CI, n = 1L)*as.factor(NAICS) + as.factor(fqtr) + 
               dplyr::lag(g_invt_phy_adj_log, n = 1L) + dplyr::lag(liquidity, n = 1L) +
               dplyr::lag(log(atq_adj), n = 1L) + dplyr::lag(saleq_adj_log_growth, n = 1L) +
               dplyr::lag(log(ppentq_adj_interp), n = 1L) + dplyr::lag(leverage, n = 1L) +dplyr::lag(tobins_q_interp, n = 1L), 
             model = c("within"), index = c("cont_id"), data = compustat), vcov. = vcovHC, type = "HC1", method = "white1", cluster = "group")
coeftest(plm(g_invt_phy_adj_log ~   dplyr::lag(T_CI, n = 1L)*highleverage + as.factor(fqtr) + 
               dplyr::lag(g_invt_phy_adj_log, n = 1L) + dplyr::lag(liquidity, n = 1L) +
               dplyr::lag(log(atq_adj), n = 1L) + dplyr::lag(saleq_adj_log_growth, n = 1L) +
               dplyr::lag(log(ppentq_adj_interp), n = 1L) + dplyr::lag(leverage, n = 1L) +dplyr::lag(tobins_q_interp, n = 1L), 
             model = c("within"), index = c("cont_id"), data = compustat), vcov. = vcovHC, type = "HC1", method = "white1", cluster = "group")
coeftest(plm(g_invt_phy_adj_log ~   dplyr::lag(T_CI, n = 1L)*high_intan + as.factor(fqtr) + 
               dplyr::lag(g_invt_phy_adj_log, n = 1L) + dplyr::lag(liquidity, n = 1L) +
               dplyr::lag(log(atq_adj), n = 1L) + dplyr::lag(saleq_adj_log_growth, n = 1L) +
               dplyr::lag(log(ppentq_adj_interp), n = 1L) + dplyr::lag(leverage, n = 1L) +dplyr::lag(tobins_q_interp, n = 1L), 
             model = c("within"), index = c("cont_id"), data = compustat), vcov. = vcovHC, type = "HC1", method = "white1", cluster = "group")
coeftest(plm(g_invt_phy_adj_log ~   dplyr::lag(T_CI, n = 1L)*high_know + as.factor(fqtr) + 
               dplyr::lag(g_invt_phy_adj_log, n = 1L) + dplyr::lag(liquidity, n = 1L) +
               dplyr::lag(log(atq_adj), n = 1L) + dplyr::lag(saleq_adj_log_growth, n = 1L) +
               dplyr::lag(log(ppentq_adj_interp), n = 1L) + dplyr::lag(leverage, n = 1L) +dplyr::lag(tobins_q_interp, n = 1L), 
             model = c("within"), index = c("cont_id"), data = compustat), vcov. = vcovHC, type = "HC1", method = "white1", cluster = "group")
coeftest(plm(g_invt_phy_adj_log ~  dplyr::lag(T_CI, n = 1L)*high_org + as.factor(fqtr) + 
               dplyr::lag(g_invt_phy_adj_log, n = 1L) + dplyr::lag(liquidity, n = 1L) +
               dplyr::lag(log(atq_adj), n = 1L) + dplyr::lag(saleq_adj_log_growth, n = 1L) +
               dplyr::lag(log(ppentq_adj_interp), n = 1L) + dplyr::lag(leverage, n = 1L) +dplyr::lag(tobins_q_interp, n = 1L), 
             model = c("within"), index = c("cont_id"), data = compustat), vcov. = vcovHC, type = "HC1", method = "white1", cluster = "group")
coeftest(plm(g_invt_phy_adj_log ~  dplyr::lag(T_CI, n = 1L)*young_firm + as.factor(fqtr) + 
               dplyr::lag(g_invt_phy_adj_log, n = 1L) + dplyr::lag(liquidity, n = 1L) +
               dplyr::lag(log(atq_adj), n = 1L) + dplyr::lag(saleq_adj_log_growth, n = 1L) +
               dplyr::lag(log(ppentq_adj_interp), n = 1L) + dplyr::lag(leverage, n = 1L) +dplyr::lag(tobins_q_interp, n = 1L), 
             model = c("within"), index = c("cont_id"), data = compustat), vcov. = vcovHC, type = "HC1", method = "white1", cluster = "group")





## Positive

## With Firm Controls

coeftest(plm(g_invt_phy_adj_log ~ dplyr::lag(T_CI_POS, n = 1L) + dplyr::lag(g_invt_phy_adj_log, n = 1L)  + as.factor(fqtr) + dplyr::lag(liquidity, n = 1L) +
               dplyr::lag(log(atq_adj), n = 1L) + dplyr::lag(saleq_adj_log_growth, n = 1L) +
               dplyr::lag(log(ppentq_adj_interp), n = 1L) + dplyr::lag(leverage, n = 1L) +dplyr::lag(tobins_q_interp, n = 1L), 
             model = c("within"), index = c("cont_id"), data = compustat), vcov. = vcovHC, type = "HC1", method = "white1", cluster = "group")
coeftest(plm(g_invt_phy_adj_log ~ dplyr::lag(T_CI_POS, n = 1L)*mnc + as.factor(fqtr)
             + dplyr::lag(g_invt_phy_adj_log, n = 1L) + dplyr::lag(liquidity, n = 1L) +
               dplyr::lag(log(atq_adj), n = 1L) + dplyr::lag(saleq_adj_log_growth, n = 1L) + dplyr::lag(tobins_q_interp, n = 1L) +
               dplyr::lag(log(ppentq_adj_interp), n = 1L) + dplyr::lag(leverage, n = 1L), 
             model = c("within"), index = c("cont_id"), data = compustat), vcov. = vcovHC, type = "HC1", method = "white1", cluster = "group")
coeftest(plm(g_invt_phy_adj_log ~   dplyr::lag(T_CI_POS, n = 1L)*high_roa  + as.factor(fqtr)  + dplyr::lag(g_invt_phy_adj_log, n = 1L) + dplyr::lag(liquidity, n = 1L) +
               dplyr::lag(log(atq_adj), n = 1L) + dplyr::lag(saleq_adj_log_growth, n = 1L) +
               dplyr::lag(log(ppentq_adj_interp), n = 1L) + dplyr::lag(leverage, n = 1L)  +dplyr::lag(tobins_q_interp, n = 1L), 
             model = c("within"), index = c("cont_id"), data = compustat), vcov. = vcovHC, type = "HC1", method = "white1", cluster = "group")
coeftest(plm(g_invt_phy_adj_log ~  dplyr::lag(T_CI_POS, n = 1L)*hp_con + as.factor(fqtr)+ 
               dplyr::lag(g_invt_phy_adj_log, n = 1L) + dplyr::lag(liquidity, n = 1L) +
               dplyr::lag(log(atq_adj), n = 1L) + dplyr::lag(saleq_adj_log_growth, n = 1L) +
               dplyr::lag(log(ppentq_adj_interp), n = 1L) + dplyr::lag(leverage, n = 1L) +dplyr::lag(tobins_q_interp, n = 1L), 
             model = c("within"), index = c("cont_id"), data = compustat), vcov. = vcovHC, type = "HC1", method = "white1", cluster = "group")
coeftest(plm(g_invt_phy_adj_log ~   dplyr::lag(T_CI_POS, n = 1L)*kz_con + as.factor(fqtr) + 
               dplyr::lag(g_invt_phy_adj_log, n = 1L) + dplyr::lag(liquidity, n = 1L) +
               dplyr::lag(log(atq_adj), n = 1L) + dplyr::lag(saleq_adj_log_growth, n = 1L) +
               dplyr::lag(log(ppentq_adj_interp), n = 1L) + dplyr::lag(leverage, n = 1L) +dplyr::lag(tobins_q_interp, n = 1L), 
             model = c("within"), index = c("cont_id"), data = compustat), vcov. = vcovHC, type = "HC1", method = "white1", cluster = "group")
coeftest(plm(g_invt_phy_adj_log ~   dplyr::lag(T_CI_POS, n = 1L)*big_firm + as.factor(fqtr) + 
               dplyr::lag(g_invt_phy_adj_log, n = 1L) + dplyr::lag(liquidity, n = 1L) +
               dplyr::lag(log(atq_adj), n = 1L) + dplyr::lag(saleq_adj_log_growth, n = 1L) +
               dplyr::lag(log(ppentq_adj_interp), n = 1L) + dplyr::lag(leverage, n = 1L) +dplyr::lag(tobins_q_interp, n = 1L), 
             model = c("within"), index = c("cont_id"), data = compustat), vcov. = vcovHC, type = "HC1", method = "white1", cluster = "group")
coeftest(plm(g_invt_phy_adj_log ~   dplyr::lag(T_CI_POS, n = 1L)*div_payer + as.factor(fqtr) + 
               dplyr::lag(g_invt_phy_adj_log, n = 1L) + dplyr::lag(liquidity, n = 1L) +
               dplyr::lag(log(atq_adj), n = 1L) + dplyr::lag(saleq_adj_log_growth, n = 1L) +
               dplyr::lag(log(ppentq_adj_interp), n = 1L) + dplyr::lag(leverage, n = 1L) +dplyr::lag(tobins_q_interp, n = 1L), 
             model = c("within"), index = c("cont_id"), data = compustat), vcov. = vcovHC, type = "HC1", method = "white1", cluster = "group")
coeftest(plm(g_invt_phy_adj_log ~   dplyr::lag(T_CI_POS, n = 1L)*as.factor(NAICS) + as.factor(fqtr) + 
               dplyr::lag(g_invt_phy_adj_log, n = 1L) + dplyr::lag(liquidity, n = 1L) +
               dplyr::lag(log(atq_adj), n = 1L) + dplyr::lag(saleq_adj_log_growth, n = 1L) +
               dplyr::lag(log(ppentq_adj_interp), n = 1L) + dplyr::lag(leverage, n = 1L) +dplyr::lag(tobins_q_interp, n = 1L), 
             model = c("within"), index = c("cont_id"), data = compustat), vcov. = vcovHC, type = "HC1", method = "white1", cluster = "group")
coeftest(plm(g_invt_phy_adj_log ~   dplyr::lag(T_CI_POS, n = 1L)*highleverage + as.factor(fqtr) + 
               dplyr::lag(g_invt_phy_adj_log, n = 1L) + dplyr::lag(liquidity, n = 1L) +
               dplyr::lag(log(atq_adj), n = 1L) + dplyr::lag(saleq_adj_log_growth, n = 1L) +
               dplyr::lag(log(ppentq_adj_interp), n = 1L) + dplyr::lag(leverage, n = 1L) +dplyr::lag(tobins_q_interp, n = 1L), 
             model = c("within"), index = c("cont_id"), data = compustat), vcov. = vcovHC, type = "HC1", method = "white1", cluster = "group")
coeftest(plm(g_invt_phy_adj_log ~   dplyr::lag(T_CI_POS, n = 1L)*high_intan + as.factor(fqtr) + 
               dplyr::lag(g_invt_phy_adj_log, n = 1L) + dplyr::lag(liquidity, n = 1L) +
               dplyr::lag(log(atq_adj), n = 1L) + dplyr::lag(saleq_adj_log_growth, n = 1L) +
               dplyr::lag(log(ppentq_adj_interp), n = 1L) + dplyr::lag(leverage, n = 1L) +dplyr::lag(tobins_q_interp, n = 1L), 
             model = c("within"), index = c("cont_id"), data = compustat), vcov. = vcovHC, type = "HC1", method = "white1", cluster = "group")
coeftest(plm(g_invt_phy_adj_log ~   dplyr::lag(T_CI_POS, n = 1L)*high_know + as.factor(fqtr) + 
               dplyr::lag(g_invt_phy_adj_log, n = 1L) + dplyr::lag(liquidity, n = 1L) +
               dplyr::lag(log(atq_adj), n = 1L) + dplyr::lag(saleq_adj_log_growth, n = 1L) +
               dplyr::lag(log(ppentq_adj_interp), n = 1L) + dplyr::lag(leverage, n = 1L) +dplyr::lag(tobins_q_interp, n = 1L), 
             model = c("within"), index = c("cont_id"), data = compustat), vcov. = vcovHC, type = "HC1", method = "white1", cluster = "group")
coeftest(plm(g_invt_phy_adj_log ~  dplyr::lag(T_CI_POS, n = 1L)*high_org + as.factor(fqtr) + 
               dplyr::lag(g_invt_phy_adj_log, n = 1L) + dplyr::lag(liquidity, n = 1L) +
               dplyr::lag(log(atq_adj), n = 1L) + dplyr::lag(saleq_adj_log_growth, n = 1L) +
               dplyr::lag(log(ppentq_adj_interp), n = 1L) + dplyr::lag(leverage, n = 1L) +dplyr::lag(tobins_q_interp, n = 1L), 
             model = c("within"), index = c("cont_id"), data = compustat), vcov. = vcovHC, type = "HC1", method = "white1", cluster = "group")
coeftest(plm(g_invt_phy_adj_log ~  dplyr::lag(T_CI_POS, n = 1L) + as.factor(fqtr) + 
               dplyr::lag(g_invt_phy_adj_log, n = 1L) + dplyr::lag(liquidity, n = 1L) +
               dplyr::lag(log(atq_adj), n = 1L) + dplyr::lag(saleq_adj_log_growth, n = 1L) +
               dplyr::lag(log(ppentq_adj_interp), n = 1L) + dplyr::lag(leverage, n = 1L) +dplyr::lag(tobins_q_interp, n = 1L), 
             model = c("within"), index = c("cont_id"), data = compusta), vcov. = vcovHC, type = "HC1", method = "white1", cluster = "group")


## NEGATIVE

## With Firm Controls

coeftest(plm(g_invt_phy_adj_log ~ dplyr::lag(T_CI_NEG, n = 1L) + dplyr::lag(g_invt_phy_adj_log, n = 1L)  + as.factor(fqtr) + dplyr::lag(liquidity, n = 1L) +
               dplyr::lag(log(atq_adj), n = 1L) + dplyr::lag(saleq_adj_log_growth, n = 1L) +
               dplyr::lag(log(ppentq_adj_interp), n = 1L) + dplyr::lag(leverage, n = 1L) +dplyr::lag(tobins_q_interp, n = 1L), 
             model = c("within"), index = c("cont_id"), data = compustat), vcov. = vcovHC, type = "HC1", method = "white1", cluster = "group")
coeftest(plm(g_invt_phy_adj_log ~ dplyr::lag(T_CI_NEG, n = 1L)*mnc + as.factor(fqtr)
             + dplyr::lag(g_invt_phy_adj_log, n = 1L) + dplyr::lag(liquidity, n = 1L) +
               dplyr::lag(log(atq_adj), n = 1L) + dplyr::lag(saleq_adj_log_growth, n = 1L) + dplyr::lag(tobins_q_interp, n = 1L) +
               dplyr::lag(log(ppentq_adj_interp), n = 1L) + dplyr::lag(leverage, n = 1L), 
             model = c("within"), index = c("cont_id"), data = compustat), vcov. = vcovHC, type = "HC1", method = "white1", cluster = "group")
coeftest(plm(g_invt_phy_adj_log ~   dplyr::lag(T_CI_NEG, n = 1L)*high_roa  + as.factor(fqtr)  + dplyr::lag(g_invt_phy_adj_log, n = 1L) + dplyr::lag(liquidity, n = 1L) +
               dplyr::lag(log(atq_adj), n = 1L) + dplyr::lag(saleq_adj_log_growth, n = 1L) +
               dplyr::lag(log(ppentq_adj_interp), n = 1L) + dplyr::lag(leverage, n = 1L)  +dplyr::lag(tobins_q_interp, n = 1L), 
             model = c("within"), index = c("cont_id"), data = compustat), vcov. = vcovHC, type = "HC1", method = "white1", cluster = "group")
coeftest(plm(g_invt_phy_adj_log ~  dplyr::lag(T_CI_NEG, n = 1L)*hp_con + as.factor(fqtr)+ 
               dplyr::lag(g_invt_phy_adj_log, n = 1L) + dplyr::lag(liquidity, n = 1L) +
               dplyr::lag(log(atq_adj), n = 1L) + dplyr::lag(saleq_adj_log_growth, n = 1L) +
               dplyr::lag(log(ppentq_adj_interp), n = 1L) + dplyr::lag(leverage, n = 1L) +dplyr::lag(tobins_q_interp, n = 1L), 
             model = c("within"), index = c("cont_id"), data = compustat), vcov. = vcovHC, type = "HC1", method = "white1", cluster = "group")
coeftest(plm(g_invt_phy_adj_log ~   dplyr::lag(T_CI_NEG, n = 1L)*kz_con + as.factor(fqtr) + 
               dplyr::lag(g_invt_phy_adj_log, n = 1L) + dplyr::lag(liquidity, n = 1L) +
               dplyr::lag(log(atq_adj), n = 1L) + dplyr::lag(saleq_adj_log_growth, n = 1L) +
               dplyr::lag(log(ppentq_adj_interp), n = 1L) + dplyr::lag(leverage, n = 1L) +dplyr::lag(tobins_q_interp, n = 1L), 
             model = c("within"), index = c("cont_id"), data = compustat), vcov. = vcovHC, type = "HC1", method = "white1", cluster = "group")
coeftest(plm(g_invt_phy_adj_log ~   dplyr::lag(T_CI_NEG, n = 1L)*big_firm + as.factor(fqtr) + 
               dplyr::lag(g_invt_phy_adj_log, n = 1L) + dplyr::lag(liquidity, n = 1L) +
               dplyr::lag(log(atq_adj), n = 1L) + dplyr::lag(saleq_adj_log_growth, n = 1L) +
               dplyr::lag(log(ppentq_adj_interp), n = 1L) + dplyr::lag(leverage, n = 1L) +dplyr::lag(tobins_q_interp, n = 1L), 
             model = c("within"), index = c("cont_id"), data = compustat), vcov. = vcovHC, type = "HC1", method = "white1", cluster = "group")
#POTENTIAL
coeftest(plm(g_invt_phy_adj_log ~   dplyr::lag(T_CI_NEG, n = 1L)*div_payer + as.factor(fqtr) + 
               dplyr::lag(g_invt_phy_adj_log, n = 1L) + dplyr::lag(liquidity, n = 1L) +
               dplyr::lag(log(atq_adj), n = 1L) + dplyr::lag(saleq_adj_log_growth, n = 1L) +
               dplyr::lag(log(ppentq_adj_interp), n = 1L) + dplyr::lag(leverage, n = 1L) +dplyr::lag(tobins_q_interp, n = 1L), 
             model = c("within"), index = c("cont_id"), data = compustat), vcov. = vcovHC, type = "HC1", method = "white1", cluster = "group")
coeftest(plm(g_invt_phy_adj_log ~   dplyr::lag(T_CI_NEG, n = 1L)*as.factor(NAICS) + as.factor(fqtr) + 
               dplyr::lag(g_invt_phy_adj_log, n = 1L) + dplyr::lag(liquidity, n = 1L) +
               dplyr::lag(log(atq_adj), n = 1L) + dplyr::lag(saleq_adj_log_growth, n = 1L) +
               dplyr::lag(log(ppentq_adj_interp), n = 1L) + dplyr::lag(leverage, n = 1L) +dplyr::lag(tobins_q_interp, n = 1L), 
             model = c("within"), index = c("cont_id"), data = compustat), vcov. = vcovHC, type = "HC1", method = "white1", cluster = "group")
coeftest(plm(g_invt_phy_adj_log ~   dplyr::lag(T_CI_NEG, n = 1L)*highleverage + as.factor(fqtr) + 
               dplyr::lag(g_invt_phy_adj_log, n = 1L) + dplyr::lag(liquidity, n = 1L) +
               dplyr::lag(log(atq_adj), n = 1L) + dplyr::lag(saleq_adj_log_growth, n = 1L) +
               dplyr::lag(log(ppentq_adj_interp), n = 1L) + dplyr::lag(leverage, n = 1L) +dplyr::lag(tobins_q_interp, n = 1L), 
             model = c("within"), index = c("cont_id"), data = compustat), vcov. = vcovHC, type = "HC1", method = "white1", cluster = "group")
coeftest(plm(g_invt_phy_adj_log ~   dplyr::lag(T_CI_NEG, n = 1L)*high_intan + as.factor(fqtr) + 
               dplyr::lag(g_invt_phy_adj_log, n = 1L) + dplyr::lag(liquidity, n = 1L) +
               dplyr::lag(log(atq_adj), n = 1L) + dplyr::lag(saleq_adj_log_growth, n = 1L) +
               dplyr::lag(log(ppentq_adj_interp), n = 1L) + dplyr::lag(leverage, n = 1L) +dplyr::lag(tobins_q_interp, n = 1L), 
             model = c("within"), index = c("cont_id"), data = compustat), vcov. = vcovHC, type = "HC1", method = "white1", cluster = "group")
coeftest(plm(g_invt_phy_adj_log ~   dplyr::lag(T_CI_NEG, n = 1L)*high_know + as.factor(fqtr) + 
               dplyr::lag(g_invt_phy_adj_log, n = 1L) + dplyr::lag(liquidity, n = 1L) +
               dplyr::lag(log(atq_adj), n = 1L) + dplyr::lag(saleq_adj_log_growth, n = 1L) +
               dplyr::lag(log(ppentq_adj_interp), n = 1L) + dplyr::lag(leverage, n = 1L) +dplyr::lag(tobins_q_interp, n = 1L), 
             model = c("within"), index = c("cont_id"), data = compustat), vcov. = vcovHC, type = "HC1", method = "white1", cluster = "group")
#HERE
coeftest(plm(g_invt_phy_adj_log ~  dplyr::lag(T_CI_NEG, n = 1L)*high_org + as.factor(fqtr) + 
               dplyr::lag(g_invt_phy_adj_log, n = 1L) + dplyr::lag(liquidity, n = 1L) +
               dplyr::lag(log(atq_adj), n = 1L) + dplyr::lag(saleq_adj_log_growth, n = 1L) +
               dplyr::lag(log(ppentq_adj_interp), n = 1L) + dplyr::lag(leverage, n = 1L) +dplyr::lag(tobins_q_interp, n = 1L), 
             model = c("within"), index = c("cont_id"), data = compustat), vcov. = vcovHC, type = "HC1", method = "white1", cluster = "group")
coeftest(plm(g_invt_phy_adj_log ~  dplyr::lag(T_CI_NEG, n = 1L)*young_firm + as.factor(fqtr) + 
               dplyr::lag(g_invt_phy_adj_log, n = 1L) + dplyr::lag(liquidity, n = 1L) +
               dplyr::lag(log(atq_adj), n = 1L) + dplyr::lag(saleq_adj_log_growth, n = 1L) +
               dplyr::lag(log(ppentq_adj_interp), n = 1L) + dplyr::lag(leverage, n = 1L) +dplyr::lag(tobins_q_interp, n = 1L), 
             model = c("within"), index = c("cont_id"), data = compustat), vcov. = vcovHC, type = "HC1", method = "white1", cluster = "group")


coeftest(plm(ltleverage ~ dplyr::lag(T_CI_POS, n = 1L) + dplyr::lag(roa, n = 1L) + dplyr::lag(intangible_intensity, n = 1L) + dplyr::lag(log(atq_adj), n = 1L) + dplyr::lag(tobins_q_interp, n = 1L), 
             model = c("within"), index = c("cont_id"), data = compustat), vcov. = vcovHC, type = "HC1", method = "white1", cluster = "group")
coeftest(plm(ltleverage ~ dplyr::lag(T_CI_POS, n = 1L) + dplyr::lag(T_CI_POS, n = 1L):dplyr::lag(highleverage, n = 1L) + dplyr::lag(roa, n = 1L) + dplyr::lag(intangible_intensity, n = 1L) + dplyr::lag(log(atq_adj), n = 1L) + dplyr::lag(tobins_q_interp, n = 1L), 
             model = c("within"), index = c("cont_id"), data = compustat), vcov. = vcovHC, type = "HC1", method = "white1", cluster = "group")
coeftest(plm(ltleverage ~ dplyr::lag(T_CI_POS, n = 1L) + dplyr::lag(T_CI_POS, n = 1L):dplyr::lag(hp_con, n = 1L) + dplyr::lag(roa, n = 1L) + dplyr::lag(intangible_intensity, n = 1L) + dplyr::lag(log(atq_adj), n = 1L) + dplyr::lag(tobins_q_interp, n = 1L), 
             model = c("within"), index = c("cont_id"), data = compustat), vcov. = vcovHC, type = "HC1", method = "white1", cluster = "group")
coeftest(plm(ltleverage ~ dplyr::lag(T_CI_POS, n = 1L) + dplyr::lag(T_CI_POS, n = 1L):dplyr::lag(big_firm, n = 1L) + dplyr::lag(roa, n = 1L) + dplyr::lag(intangible_intensity, n = 1L) + dplyr::lag(log(atq_adj), n = 1L) + dplyr::lag(tobins_q_interp, n = 1L), 
             model = c("within"), index = c("cont_id"), data = compustat), vcov. = vcovHC, type = "HC1", method = "white1", cluster = "group")
coeftest(plm(ltleverage ~ dplyr::lag(T_CI_POS, n = 1L) + dplyr::lag(T_CI_POS, n = 1L):dplyr::lag(div_payer, n = 1L) + dplyr::lag(roa, n = 1L) + dplyr::lag(intangible_intensity, n = 1L) + dplyr::lag(log(atq_adj), n = 1L) + dplyr::lag(tobins_q_interp, n = 1L), 
             model = c("within"), index = c("cont_id"), data = compustat), vcov. = vcovHC, type = "HC1", method = "white1", cluster = "group")
coeftest(plm(ltleverage ~ dplyr::lag(T_CI_POS, n = 1L) + dplyr::lag(T_CI_POS, n = 1L):dplyr::lag(young_firm, n = 1L) + dplyr::lag(roa, n = 1L) + dplyr::lag(intangible_intensity, n = 1L) + dplyr::lag(log(atq_adj), n = 1L) + dplyr::lag(tobins_q_interp, n = 1L), 
             model = c("within"), index = c("cont_id"), data = compustat), vcov. = vcovHC, type = "HC1", method = "white1", cluster = "group")


models <- list(
            b1 = plm(ltleverage ~ dplyr::lag(T_CI_POS, n = 1L) + dplyr::lag(roa, n = 1L) + dplyr::lag(intangible_intensity, n = 1L) + dplyr::lag(log(atq_adj), n = 1L) + dplyr::lag(tobins_q_interp, n = 1L), 
             model = c("within"), index = c("cont_id"), data = compustat),
             b2 = plm(ltleverage ~ dplyr::lag(T_CI_POS, n = 1L) + dplyr::lag(T_CI_POS, n = 1L):dplyr::lag(highleverage, n = 1L) + dplyr::lag(roa, n = 1L) + dplyr::lag(intangible_intensity, n = 1L) + dplyr::lag(log(atq_adj), n = 1L) + dplyr::lag(tobins_q_interp, n = 1L), 
             model = c("within"),  index = c("cont_id"),data = compustat),
            b3 = plm(ltleverage ~ dplyr::lag(T_CI_POS, n = 1L) + dplyr::lag(T_CI_POS, n = 1L):dplyr::lag(hp_con, n = 1L) + dplyr::lag(roa, n = 1L) + dplyr::lag(intangible_intensity, n = 1L) + dplyr::lag(log(atq_adj), n = 1L) + dplyr::lag(tobins_q_interp, n = 1L), 
             model = c("within"),  index = c("cont_id"),data = compustat),
            b4 = plm(ltleverage ~ dplyr::lag(T_CI_POS, n = 1L) + dplyr::lag(T_CI_POS, n = 1L):dplyr::lag(big_firm, n = 1L) + dplyr::lag(roa, n = 1L) + dplyr::lag(intangible_intensity, n = 1L) + dplyr::lag(log(atq_adj), n = 1L) + dplyr::lag(tobins_q_interp, n = 1L), 
             model = c("within"),  index = c("cont_id"),data = compustat),
            b5 = plm(ltleverage ~ dplyr::lag(T_CI_POS, n = 1L) + dplyr::lag(T_CI_POS, n = 1L):dplyr::lag(div_payer, n = 1L) + dplyr::lag(roa, n = 1L) + dplyr::lag(intangible_intensity, n = 1L) + dplyr::lag(log(atq_adj), n = 1L) + dplyr::lag(tobins_q_interp, n = 1L), 
             model = c("within"),  index = c("cont_id"),data = compustat),
            b6 = plm(ltleverage ~ dplyr::lag(T_CI_POS, n = 1L) + dplyr::lag(T_CI_POS, n = 1L):dplyr::lag(young_firm, n = 1L) + dplyr::lag(roa, n = 1L) + dplyr::lag(intangible_intensity, n = 1L) + dplyr::lag(log(atq_adj), n = 1L) + dplyr::lag(tobins_q_interp, n = 1L), 
             model = c("within"),  index = c("cont_id"),data = compustat)
)


se_robust <- function(x){
  coeftest(x, vcov. = vcovHC, type = "HC1", method = "white1", cluster = "group")
}
library(stargazer)
stargazer(
  models, single.row = TRUE, 
  se = lapply(models, se_robust))


compustat <- compustat %>% mutate(payout_scale = payout/atq_adj, 
                                  equity_issue_scale = equity_issue/atq_adj,
                                  other_sources = other_sources/atq_adj)

coeftest(plm(diff(payout_scale) ~ diff(equity_issue_scale) + diff(other_sources) + log(atq_adj),
             model = c("within"), index = c("cont_id"), data = compustat), vcov. = vcovHC, type = "HC1", method = "white1", cluster = "group")
coeftest(plm(diff(payout_scale) ~ diff(equity_issue_scale) + diff(equity_issue_scale):highleverage + diff(other_sources)+
               diff(other_sources):highleverage + diff(log(atq_adj)) + diff(log(atq_adj)):highleverage,
             model = c("within"), index = c("cont_id"), data = compustat), vcov. = vcovHC, type = "HC1", method = "white1", cluster = "group")
coeftest(plm(diff(payout_scale) ~ diff(equity_issue_scale) + diff(equity_issue_scale):hp_con + diff(other_sources)+
               diff(other_sources):hp_con + diff(log(atq_adj)) + diff(log(atq_adj)):hp_con,
             model = c("within"), index = c("cont_id"), data = compustat), vcov. = vcovHC, type = "HC1", method = "white1", cluster = "group")
coeftest(plm(diff(payout_scale) ~ diff(equity_issue_scale) + diff(equity_issue_scale):big_firm + diff(other_sources)+
               diff(other_sources):big_firm + diff(log(atq_adj)) + diff(log(atq_adj)):big_firm,
             model = c("within"), index = c("cont_id"), data = compustat), vcov. = vcovHC, type = "HC1", method = "white1", cluster = "group")
coeftest(plm(diff(payout_scale) ~ diff(equity_issue_scale) + diff(equity_issue_scale):div_payer + diff(other_sources)+
               diff(other_sources):div_payer + diff(log(atq_adj)) + diff(log(atq_adj)):div_payer,
             model = c("within"), index = c("cont_id"), data = compustat), vcov. = vcovHC, type = "HC1", method = "white1", cluster = "group")
coeftest(plm(diff(payout_scale) ~ diff(equity_issue_scale) + diff(equity_issue_scale):young_firm + diff(other_sources)+
               diff(other_sources):young_firm + diff(log(atq_adj)) + diff(log(atq_adj)):young_firm,
             model = c("within"), index = c("cont_id"), data = compustat), vcov. = vcovHC, type = "HC1", method = "white1", cluster = "group")




lev <- compustat %>% dplyr::select(-c(V1)) %>% group_by(age) %>% summarise("Leverage" = mean(leverage, na.rm = T)) %>% filter(age<=50)
ggplot(data = lev) + geom_line(aes(x = age, y = Leverage), size = 1.1)  +  theme_minimal() + theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
  theme(panel.border = element_blank(), axis.line = element_line()) + xlab("Age")

compuslev <- compustatlev %>% left_join(lev, by = c("age"))

ggplot(data = compuslev) + 
    geom_line(aes(x = age, y = Leverage.x, color = "Full Compustat"), size = 1.1) +
    geom_line(aes(x = age, y = Leverage.y, color = "Filtered Sample"), size = 1.1) +  theme_minimal() + theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
    theme(panel.border = element_blank(), axis.line = element_line()) + 
    xlab("Age") + ylab("Leverage") + theme(legend.title=element_blank()) + theme(legend.position=c(.25, .85))
